import React from 'react';
import { FileText } from 'lucide-react';
import { Card } from '@/components/ui/Card';

export const TermsPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-bg py-12 animate-fade-in">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-navy/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <FileText className="w-8 h-8 text-navy" />
          </div>
          <h1 className="text-3xl font-bold text-navy mb-2">Terms of Service</h1>
          <p className="text-gray-600">Last updated: January 2025</p>
        </div>
        
        <Card className="prose prose-slate max-w-none">
          <div className="space-y-6 text-gray-700">
            <section>
              <h2 className="text-xl font-semibold text-navy mb-3">1. Acceptance of Terms</h2>
              <p>
                By accessing and using Rajpal Solutions (rajpalsolutions.in), you accept and agree 
                to be bound by these Terms of Service. If you do not agree to these terms, 
                please do not use our services.
              </p>
            </section>
            
            <section>
              <h2 className="text-xl font-semibold text-navy mb-3">2. Description of Services</h2>
              <p>
                Rajpal Solutions provides assistance with government service applications including 
                but not limited to:
              </p>
              <ul className="list-disc pl-6 space-y-1 mt-2">
                <li>PAN Card services (new, correction, reprint)</li>
                <li>Aadhaar update assistance</li>
                <li>Voter ID registration and correction</li>
                <li>Driving License services</li>
                <li>Vehicle registration services</li>
                <li>Land record services (Khasra, B1, Naksha)</li>
                <li>Certificate services (Income, Residence, Caste)</li>
                <li>Welfare scheme registrations</li>
              </ul>
              <p className="mt-3 bg-blue-50 p-3 rounded-lg">
                <strong>Note:</strong> We are a facilitation service. We do not guarantee approval 
                of any government application as final decisions rest with respective government authorities.
              </p>
            </section>
            
            <section>
              <h2 className="text-xl font-semibold text-navy mb-3">3. User Responsibilities</h2>
              <p className="mb-2">As a user of our services, you agree to:</p>
              <ul className="list-disc pl-6 space-y-1">
                <li>Provide accurate and truthful information</li>
                <li>Upload authentic documents only</li>
                <li>Not use our services for any illegal purposes</li>
                <li>Keep your account credentials confidential</li>
                <li>Notify us immediately of any unauthorized access</li>
                <li>Not impersonate any person or entity</li>
              </ul>
            </section>
            
            <section>
              <h2 className="text-xl font-semibold text-navy mb-3">4. Service Fees and Payments</h2>
              <ul className="list-disc pl-6 space-y-1">
                <li>Service fees are clearly displayed before submission</li>
                <li>Additional government fees may apply and are collected separately</li>
                <li>Delivery charges apply for home delivery option</li>
                <li>Online payments are processed securely through Razorpay</li>
                <li>Offline payments can be made at partner centers</li>
                <li>All fees are non-refundable except as stated in our Refund Policy</li>
              </ul>
            </section>
            
            <section>
              <h2 className="text-xl font-semibold text-navy mb-3">5. Processing Time</h2>
              <p>
                Processing times mentioned are estimates based on normal circumstances. 
                Actual processing time may vary due to:
              </p>
              <ul className="list-disc pl-6 space-y-1 mt-2">
                <li>Government office workload and holidays</li>
                <li>Incomplete or incorrect documentation</li>
                <li>Verification requirements</li>
                <li>Technical issues at government portals</li>
              </ul>
              <p className="mt-2">
                We are not liable for delays caused by factors beyond our control.
              </p>
            </section>
            
            <section>
              <h2 className="text-xl font-semibold text-navy mb-3">6. Partner Network</h2>
              <p>
                Service fulfillment may be done through our partner network (cyber cafes, 
                CSC centers). Partners are independently operated businesses that have 
                agreed to follow our quality standards.
              </p>
            </section>
            
            <section>
              <h2 className="text-xl font-semibold text-navy mb-3">7. Intellectual Property</h2>
              <p>
                All content, logos, and materials on this website are the property of 
                Rajpal Solutions. Unauthorized use, reproduction, or distribution is prohibited.
              </p>
            </section>
            
            <section>
              <h2 className="text-xl font-semibold text-navy mb-3">8. Limitation of Liability</h2>
              <p>
                To the maximum extent permitted by law, Rajpal Solutions shall not be liable for:
              </p>
              <ul className="list-disc pl-6 space-y-1 mt-2">
                <li>Rejection of applications by government authorities</li>
                <li>Delays in government processing</li>
                <li>Loss of documents submitted physically</li>
                <li>Any indirect or consequential damages</li>
                <li>Issues arising from inaccurate user-provided information</li>
              </ul>
            </section>
            
            <section>
              <h2 className="text-xl font-semibold text-navy mb-3">9. Dispute Resolution</h2>
              <p>
                Any disputes arising from these terms shall be resolved through:
              </p>
              <ol className="list-decimal pl-6 space-y-1 mt-2">
                <li>Direct discussion with our customer support</li>
                <li>Mediation, if direct discussion fails</li>
                <li>Arbitration under Indian Arbitration and Conciliation Act</li>
              </ol>
              <p className="mt-2">
                Courts in Damoh, Madhya Pradesh shall have exclusive jurisdiction.
              </p>
            </section>
            
            <section>
              <h2 className="text-xl font-semibold text-navy mb-3">10. Modification of Terms</h2>
              <p>
                We reserve the right to modify these terms at any time. Continued use of 
                our services after changes constitutes acceptance of the modified terms.
              </p>
            </section>
            
            <section>
              <h2 className="text-xl font-semibold text-navy mb-3">11. Termination</h2>
              <p>
                We may terminate or suspend your access to our services immediately, 
                without prior notice, for conduct that we believe violates these Terms 
                or is harmful to other users, us, or third parties.
              </p>
            </section>
            
            <section>
              <h2 className="text-xl font-semibold text-navy mb-3">12. Contact Information</h2>
              <div className="bg-gray-50 p-4 rounded-lg mt-2">
                <p><strong>Rajpal Solutions</strong></p>
                <p>In front of District Collectorate, Maharana Pratap Chouraha</p>
                <p>Jabalpur Naka, Damoh 470661, Madhya Pradesh</p>
                <p>Phone: 8269342506, 8085227600</p>
                <p>Website: rajpalsolutions.in</p>
              </div>
            </section>
          </div>
        </Card>
      </div>
    </div>
  );
};
