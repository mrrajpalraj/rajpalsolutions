import React from 'react';
import { Shield } from 'lucide-react';
import { Card } from '@/components/ui/Card';

export const PrivacyPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-bg py-12 animate-fade-in">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-green/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <Shield className="w-8 h-8 text-green" />
          </div>
          <h1 className="text-3xl font-bold text-navy mb-2">Privacy Policy</h1>
          <p className="text-gray-600">Last updated: January 2025</p>
        </div>
        
        <Card className="prose prose-slate max-w-none">
          <div className="space-y-6 text-gray-700">
            <section>
              <h2 className="text-xl font-semibold text-navy mb-3">1. Introduction</h2>
              <p>
                Rajpal Solutions ("we," "our," or "us") is committed to protecting your privacy. 
                This Privacy Policy explains how we collect, use, disclose, and safeguard your 
                information when you use our government service assistance portal at rajpalsolutions.in.
              </p>
            </section>
            
            <section>
              <h2 className="text-xl font-semibold text-navy mb-3">2. Information We Collect</h2>
              <p className="mb-2">We collect information that you provide directly to us, including:</p>
              <ul className="list-disc pl-6 space-y-1">
                <li>Personal identification information (name, mobile number, email)</li>
                <li>Address and location information</li>
                <li>Government ID details (as required for specific services)</li>
                <li>Documents uploaded for service processing</li>
                <li>Payment information (processed securely through Razorpay)</li>
              </ul>
              <p className="mt-3 bg-yellow-50 p-3 rounded-lg">
                <strong>Important:</strong> We do NOT store full Aadhaar numbers. Only the last 4 digits 
                may be collected for verification purposes with your explicit consent.
              </p>
            </section>
            
            <section>
              <h2 className="text-xl font-semibold text-navy mb-3">3. How We Use Your Information</h2>
              <ul className="list-disc pl-6 space-y-1">
                <li>To process your service requests</li>
                <li>To communicate with you about your applications</li>
                <li>To assign requests to partner service centers</li>
                <li>To process payments and issue invoices</li>
                <li>To improve our services and user experience</li>
                <li>To comply with legal obligations</li>
              </ul>
            </section>
            
            <section>
              <h2 className="text-xl font-semibold text-navy mb-3">4. Data Security</h2>
              <p>
                We implement appropriate technical and organizational security measures to protect 
                your personal data. Sensitive information is encrypted at rest using industry-standard 
                encryption. All data transmission is secured using SSL/TLS protocols.
              </p>
            </section>
            
            <section>
              <h2 className="text-xl font-semibold text-navy mb-3">5. Data Sharing</h2>
              <p className="mb-2">We may share your information with:</p>
              <ul className="list-disc pl-6 space-y-1">
                <li>Partner service centers assigned to process your request</li>
                <li>Government agencies as required for service fulfillment</li>
                <li>Payment processors (Razorpay) for transaction processing</li>
                <li>Legal authorities when required by law</li>
              </ul>
              <p className="mt-2">
                We do not sell your personal information to third parties.
              </p>
            </section>
            
            <section>
              <h2 className="text-xl font-semibold text-navy mb-3">6. Data Retention</h2>
              <p>
                We retain your personal data for as long as necessary to fulfill the purposes 
                for which it was collected, including to satisfy legal, accounting, or reporting 
                requirements. Service request data is retained for 7 years for audit purposes.
              </p>
            </section>
            
            <section>
              <h2 className="text-xl font-semibold text-navy mb-3">7. Your Rights</h2>
              <p className="mb-2">You have the right to:</p>
              <ul className="list-disc pl-6 space-y-1">
                <li>Access your personal data</li>
                <li>Correct inaccurate information</li>
                <li>Request deletion of your data (subject to legal requirements)</li>
                <li>Withdraw consent for data processing</li>
                <li>Receive a copy of your data in a portable format</li>
              </ul>
            </section>
            
            <section>
              <h2 className="text-xl font-semibold text-navy mb-3">8. Cookies and Tracking</h2>
              <p>
                We use essential cookies to maintain your session and preferences. 
                We do not use tracking cookies for advertising purposes.
              </p>
            </section>
            
            <section>
              <h2 className="text-xl font-semibold text-navy mb-3">9. Contact Us</h2>
              <p>
                If you have questions about this Privacy Policy or your personal data, contact us at:
              </p>
              <div className="bg-gray-50 p-4 rounded-lg mt-2">
                <p><strong>Rajpal Solutions</strong></p>
                <p>In front of District Collectorate, Maharana Pratap Chouraha</p>
                <p>Jabalpur Naka, Damoh 470661</p>
                <p>Phone: 8269342506, 8085227600</p>
                <p>Email: privacy@rajpalsolutions.in</p>
              </div>
            </section>
            
            <section>
              <h2 className="text-xl font-semibold text-navy mb-3">10. Changes to This Policy</h2>
              <p>
                We may update this Privacy Policy from time to time. We will notify you of any 
                changes by posting the new policy on this page and updating the "Last updated" date.
              </p>
            </section>
          </div>
        </Card>
      </div>
    </div>
  );
};
