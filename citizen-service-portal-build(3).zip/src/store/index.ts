import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { 
  User, 
  Partner, 
  ServiceRequest, 
  StatusEvent, 
  WalletTransaction,
  VerificationStatus,
  AuditLog
} from '@/types';

// Generate unique IDs
const generateId = () => Math.random().toString(36).substr(2, 9);

// Auth Store
interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  otpSent: boolean;
  pendingMobile: string | null;
  login: (mobile: string) => void;
  verifyOtp: (otp: string) => boolean;
  logout: () => void;
  updateUser: (data: Partial<User>) => void;
  setRole: (role: 'USER' | 'PARTNER' | 'ADMIN') => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      user: null,
      isAuthenticated: false,
      otpSent: false,
      pendingMobile: null,
      
      login: (mobile: string) => {
        // In dev mode, any OTP will work
        console.log(`[DEV] OTP sent to ${mobile}: 123456`);
        set({ otpSent: true, pendingMobile: mobile });
      },
      
      verifyOtp: (otp: string) => {
        const { pendingMobile } = get();
        // Mock OTP verification - accept 123456 in dev
        if (otp === '123456' && pendingMobile) {
          // Check if user exists or create new
          const existingUsers = JSON.parse(localStorage.getItem('users') || '[]');
          let user = existingUsers.find((u: User) => u.mobile === pendingMobile);
          
          if (!user) {
            user = {
              id: generateId(),
              mobile: pendingMobile,
              role: 'USER' as const,
              createdAt: new Date().toISOString()
            };
            existingUsers.push(user);
            localStorage.setItem('users', JSON.stringify(existingUsers));
          }
          
          set({ 
            user, 
            isAuthenticated: true, 
            otpSent: false, 
            pendingMobile: null 
          });
          return true;
        }
        return false;
      },
      
      logout: () => {
        set({ 
          user: null, 
          isAuthenticated: false, 
          otpSent: false, 
          pendingMobile: null 
        });
      },
      
      updateUser: (data: Partial<User>) => {
        const { user } = get();
        if (user) {
          const updatedUser = { ...user, ...data };
          set({ user: updatedUser });
          
          // Update in localStorage
          const existingUsers = JSON.parse(localStorage.getItem('users') || '[]');
          const idx = existingUsers.findIndex((u: User) => u.id === user.id);
          if (idx !== -1) {
            existingUsers[idx] = updatedUser;
            localStorage.setItem('users', JSON.stringify(existingUsers));
          }
        }
      },
      
      setRole: (role) => {
        const { user } = get();
        if (user) {
          const updatedUser = { ...user, role };
          set({ user: updatedUser });
        }
      }
    }),
    { name: 'auth-storage' }
  )
);

// Request Store
interface RequestState {
  requests: ServiceRequest[];
  statusEvents: StatusEvent[];
  createRequest: (request: Omit<ServiceRequest, 'id' | 'createdAt' | 'updatedAt'>) => ServiceRequest;
  updateRequest: (id: string, data: Partial<ServiceRequest>, actorId: string, actorRole: 'USER' | 'PARTNER' | 'ADMIN', note?: string) => void;
  getRequestsByUser: (userId: string) => ServiceRequest[];
  getRequestsByPartner: (partnerId: string) => ServiceRequest[];
  getRequestById: (id: string) => ServiceRequest | undefined;
  getStatusEvents: (requestId: string) => StatusEvent[];
  assignPartner: (requestId: string, partnerId: string, actorId: string) => void;
}

export const useRequestStore = create<RequestState>()(
  persist(
    (set, get) => ({
      requests: [],
      statusEvents: [],
      
      createRequest: (request) => {
        const newRequest: ServiceRequest = {
          ...request,
          id: generateId(),
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        };
        
        const statusEvent: StatusEvent = {
          id: generateId(),
          requestId: newRequest.id,
          status: newRequest.status,
          note: 'Request created',
          actorId: request.userId,
          actorRole: 'USER',
          createdAt: new Date().toISOString()
        };
        
        set(state => ({
          requests: [...state.requests, newRequest],
          statusEvents: [...state.statusEvents, statusEvent]
        }));
        
        return newRequest;
      },
      
      updateRequest: (id, data, actorId, actorRole, note) => {
        set(state => {
          const requests = state.requests.map(req => 
            req.id === id 
              ? { ...req, ...data, updatedAt: new Date().toISOString() }
              : req
          );
          
          const statusEvents = data.status 
            ? [...state.statusEvents, {
                id: generateId(),
                requestId: id,
                status: data.status,
                note: note || `Status updated to ${data.status}`,
                actorId,
                actorRole,
                createdAt: new Date().toISOString()
              }]
            : state.statusEvents;
          
          return { requests, statusEvents };
        });
      },
      
      getRequestsByUser: (userId) => {
        return get().requests.filter(r => r.userId === userId);
      },
      
      getRequestsByPartner: (partnerId) => {
        return get().requests.filter(r => r.partnerId === partnerId);
      },
      
      getRequestById: (id) => {
        return get().requests.find(r => r.id === id);
      },
      
      getStatusEvents: (requestId) => {
        return get().statusEvents.filter(e => e.requestId === requestId);
      },
      
      assignPartner: (requestId, partnerId, actorId) => {
        get().updateRequest(
          requestId, 
          { partnerId, status: 'ASSIGNED' }, 
          actorId, 
          'ADMIN', 
          `Assigned to partner`
        );
      }
    }),
    { name: 'request-storage' }
  )
);

// Partner Store
interface PartnerState {
  partners: Partner[];
  walletTransactions: WalletTransaction[];
  createPartner: (partner: Omit<Partner, 'id' | 'createdAt' | 'walletBalance'>) => Partner;
  updatePartner: (id: string, data: Partial<Partner>) => void;
  getPartnerByUserId: (userId: string) => Partner | undefined;
  getPartnerById: (id: string) => Partner | undefined;
  approvePartner: (id: string) => void;
  rejectPartner: (id: string) => void;
  addWalletTransaction: (partnerId: string, type: 'CREDIT' | 'DEBIT', amount: number, description: string, requestId?: string, createdBy?: string) => void;
  getWalletTransactions: (partnerId: string) => WalletTransaction[];
}

export const usePartnerStore = create<PartnerState>()(
  persist(
    (set, get) => ({
      partners: [
        // Seed partners
        {
          id: 'partner1',
          userId: 'p1user',
          shopName: 'Sharma Cyber Cafe',
          ownerName: 'Ramesh Sharma',
          address: 'Main Road, Damoh',
          mobile: '9876543210',
          block: 'damoh',
          servicesOffered: ['pan_new', 'aadhaar_update', 'income_certificate'],
          verificationStatus: 'APPROVED' as VerificationStatus,
          walletBalance: 5000,
          createdAt: new Date().toISOString()
        },
        {
          id: 'partner2',
          userId: 'p2user',
          shopName: 'Digital India Point',
          ownerName: 'Suresh Patel',
          address: 'Bus Stand, Pathariya',
          mobile: '9876543211',
          block: 'pathariya',
          servicesOffered: ['pan_new', 'voter_new', 'khasra_nakal'],
          verificationStatus: 'APPROVED' as VerificationStatus,
          walletBalance: 3000,
          createdAt: new Date().toISOString()
        }
      ],
      walletTransactions: [],
      
      createPartner: (partner) => {
        const newPartner: Partner = {
          ...partner,
          id: generateId(),
          walletBalance: 0,
          createdAt: new Date().toISOString()
        };
        set(state => ({ partners: [...state.partners, newPartner] }));
        return newPartner;
      },
      
      updatePartner: (id, data) => {
        set(state => ({
          partners: state.partners.map(p => p.id === id ? { ...p, ...data } : p)
        }));
      },
      
      getPartnerByUserId: (userId) => {
        return get().partners.find(p => p.userId === userId);
      },
      
      getPartnerById: (id) => {
        return get().partners.find(p => p.id === id);
      },
      
      approvePartner: (id) => {
        get().updatePartner(id, { verificationStatus: 'APPROVED' });
      },
      
      rejectPartner: (id) => {
        get().updatePartner(id, { verificationStatus: 'REJECTED' });
      },
      
      addWalletTransaction: (partnerId, type, amount, description, requestId, createdBy = 'system') => {
        const transaction: WalletTransaction = {
          id: generateId(),
          partnerId,
          type,
          amount,
          description,
          requestId,
          createdAt: new Date().toISOString(),
          createdBy
        };
        
        set(state => {
          const partner = state.partners.find(p => p.id === partnerId);
          if (!partner) return state;
          
          const newBalance = type === 'CREDIT' 
            ? partner.walletBalance + amount 
            : partner.walletBalance - amount;
          
          return {
            partners: state.partners.map(p => 
              p.id === partnerId ? { ...p, walletBalance: newBalance } : p
            ),
            walletTransactions: [...state.walletTransactions, transaction]
          };
        });
      },
      
      getWalletTransactions: (partnerId) => {
        return get().walletTransactions.filter(t => t.partnerId === partnerId);
      }
    }),
    { name: 'partner-storage' }
  )
);

// Admin Store
interface AdminState {
  auditLogs: AuditLog[];
  addAuditLog: (log: Omit<AuditLog, 'id' | 'createdAt'>) => void;
  getAuditLogs: () => AuditLog[];
}

export const useAdminStore = create<AdminState>()(
  persist(
    (set, get) => ({
      auditLogs: [],
      
      addAuditLog: (log) => {
        const newLog: AuditLog = {
          ...log,
          id: generateId(),
          createdAt: new Date().toISOString()
        };
        set(state => ({ auditLogs: [...state.auditLogs, newLog] }));
      },
      
      getAuditLogs: () => get().auditLogs
    }),
    { name: 'admin-storage' }
  )
);

// UI Store
interface UIState {
  sidebarOpen: boolean;
  language: 'en' | 'hi';
  toggleSidebar: () => void;
  setLanguage: (lang: 'en' | 'hi') => void;
}

export const useUIStore = create<UIState>()(
  persist(
    (set) => ({
      sidebarOpen: false,
      language: 'hi',
      toggleSidebar: () => set(state => ({ sidebarOpen: !state.sidebarOpen })),
      setLanguage: (language) => set({ language })
    }),
    { name: 'ui-storage' }
  )
);
