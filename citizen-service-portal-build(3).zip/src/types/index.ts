// User Roles
export type UserRole = 'USER' | 'PARTNER' | 'ADMIN';

// Request Status
export type RequestStatus = 
  | 'DRAFT' 
  | 'SUBMITTED' 
  | 'AWAITING_DOCUMENTS' 
  | 'IN_REVIEW' 
  | 'ASSIGNED' 
  | 'PROCESSING' 
  | 'READY' 
  | 'COMPLETED' 
  | 'CLOSED' 
  | 'REFUNDED';

// Payment Mode
export type PaymentMode = 'ONLINE' | 'OFFLINE_AT_PARTNER';

// Payment Status
export type PaymentStatus = 'PENDING' | 'PAID' | 'FAILED' | 'REFUNDED' | 'OFFLINE_PENDING' | 'OFFLINE_VERIFIED';

// Fulfillment Method
export type FulfillmentMethod = 'DIGITAL_ONLY' | 'PARTNER_PICKUP' | 'HOME_DELIVERY';

// Delivery Status
export type DeliveryStatus = 'PENDING' | 'DISPATCHED' | 'OUT_FOR_DELIVERY' | 'DELIVERED' | 'FAILED';

// Partner Verification Status
export type VerificationStatus = 'PENDING' | 'UNDER_REVIEW' | 'APPROVED' | 'REJECTED';

// User Interface
export interface User {
  id: string;
  mobile: string;
  name?: string;
  email?: string;
  role: UserRole;
  createdAt: string;
  aadhaarLast4?: string;
}

// Partner Interface
export interface Partner {
  id: string;
  userId: string;
  shopName: string;
  ownerName: string;
  address: string;
  mobile: string;
  block: string;
  servicesOffered: string[];
  verificationStatus: VerificationStatus;
  walletBalance: number;
  createdAt: string;
}

// Wallet Transaction
export interface WalletTransaction {
  id: string;
  partnerId: string;
  type: 'CREDIT' | 'DEBIT';
  amount: number;
  description: string;
  requestId?: string;
  createdAt: string;
  createdBy: string;
}

// Service Category
export interface ServiceCategory {
  id: string;
  name: string;
  nameHi: string;
  icon: string;
  description: string;
}

// Service
export interface Service {
  id: string;
  categoryId: string;
  name: string;
  nameHi: string;
  description: string;
  price: number;
  deliveryFee: number;
  processingTime: string;
  formSchema: FormSchema;
  isActive: boolean;
}

// Form Schema Types
export interface FormField {
  key: string;
  label: string;
  labelHi?: string;
  type: 'text' | 'email' | 'tel' | 'date' | 'select' | 'radio' | 'checkbox' | 'textarea' | 'number';
  required: boolean;
  placeholder?: string;
  options?: string[];
  validation?: {
    pattern?: string;
    minLength?: number;
    maxLength?: number;
    min?: number;
    max?: number;
  };
  conditionalOn?: {
    field: string;
    value: string | boolean;
  };
}

export interface UploadField {
  tag: string;
  label: string;
  labelHi?: string;
  required: boolean;
  acceptedTypes?: string[];
  maxSizeMB?: number;
}

export interface FormStep {
  title: string;
  titleHi?: string;
  fields?: FormField[];
  uploads?: UploadField[];
}

export interface FormSchema {
  service: string;
  steps: FormStep[];
  consent: {
    text: string;
    textHi?: string;
  };
}

// Service Request
export interface ServiceRequest {
  id: string;
  userId: string;
  serviceId: string;
  status: RequestStatus;
  formData: Record<string, any>;
  uploads: UploadedFile[];
  paymentMode: PaymentMode;
  paymentStatus: PaymentStatus;
  fulfillmentMethod: FulfillmentMethod;
  deliveryAddress?: DeliveryAddress;
  deliveryStatus?: DeliveryStatus;
  deliveryProof?: string;
  partnerId?: string;
  totalAmount: number;
  platformFee: number;
  createdAt: string;
  updatedAt: string;
  consentGiven: boolean;
}

// Uploaded File
export interface UploadedFile {
  id: string;
  tag: string;
  fileName: string;
  fileUrl: string;
  uploadedAt: string;
}

// Delivery Address
export interface DeliveryAddress {
  name: string;
  mobile: string;
  addressLine1: string;
  addressLine2?: string;
  city: string;
  district: string;
  state: string;
  pincode: string;
}

// Status Event
export interface StatusEvent {
  id: string;
  requestId: string;
  status: RequestStatus;
  note?: string;
  actorId: string;
  actorRole: UserRole;
  createdAt: string;
}

// Audit Log
export interface AuditLog {
  id: string;
  action: string;
  entityType: string;
  entityId: string;
  actorId: string;
  actorRole: UserRole;
  details: Record<string, any>;
  createdAt: string;
}

// Block (District subdivision)
export interface Block {
  id: string;
  name: string;
  district: string;
}

// OTP
export interface OTPRequest {
  mobile: string;
  otp: string;
  purpose: 'LOGIN' | 'PAYMENT_VERIFICATION';
  expiresAt: string;
}
