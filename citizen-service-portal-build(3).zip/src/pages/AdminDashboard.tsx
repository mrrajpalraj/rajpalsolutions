import React, { useState } from 'react';
import { 
  LayoutDashboard, 
  FileText, 
  Users, 
  Settings,
  TrendingUp,
  Clock,
  CheckCircle,
  AlertCircle,
  ArrowRight,
  Plus,
  UserCheck,
  Wallet,
  Search
} from 'lucide-react';
import { Card, CardHeader } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import { Modal } from '@/components/ui/Modal';
import { StatusBadge, VerificationBadge } from '@/components/ui/Badge';
import { useAuthStore, useRequestStore, usePartnerStore, useAdminStore } from '@/store';
import { services } from '@/data/services';

type TabType = 'overview' | 'requests' | 'partners' | 'services' | 'audit';

export const AdminDashboard: React.FC = () => {
  const { user, setRole } = useAuthStore();
  const { requests, assignPartner } = useRequestStore();
  const { partners, approvePartner, rejectPartner, addWalletTransaction } = usePartnerStore();
  const { getAuditLogs, addAuditLog } = useAdminStore();
  
  const [activeTab, setActiveTab] = useState<TabType>('overview');
  const [selectedRequest, setSelectedRequest] = useState<any>(null);
  const [showAssignModal, setShowAssignModal] = useState(false);
  const [showWalletModal, setShowWalletModal] = useState(false);
  const [selectedPartner, setSelectedPartner] = useState<any>(null);
  const [walletAmount, setWalletAmount] = useState('');
  const [walletNote, setWalletNote] = useState('');
  
  const auditLogs = getAuditLogs();
  
  // Stats
  const stats = {
    totalRequests: requests.length,
    pendingRequests: requests.filter(r => ['SUBMITTED', 'IN_REVIEW'].includes(r.status)).length,
    completedRequests: requests.filter(r => r.status === 'COMPLETED').length,
    totalPartners: partners.length,
    pendingPartners: partners.filter(p => p.verificationStatus === 'PENDING').length,
    totalRevenue: requests.filter(r => r.paymentStatus === 'PAID').reduce((sum, r) => sum + r.totalAmount, 0)
  };
  
  const handleAssignPartner = (partnerId: string) => {
    if (!selectedRequest || !user) return;
    assignPartner(selectedRequest.id, partnerId, user.id);
    addAuditLog({
      action: 'ASSIGN_PARTNER',
      entityType: 'REQUEST',
      entityId: selectedRequest.id,
      actorId: user.id,
      actorRole: 'ADMIN',
      details: { partnerId }
    });
    setShowAssignModal(false);
    setSelectedRequest(null);
  };
  
  const handleApprovePartner = (partnerId: string) => {
    if (!user) return;
    approvePartner(partnerId);
    addAuditLog({
      action: 'APPROVE_PARTNER',
      entityType: 'PARTNER',
      entityId: partnerId,
      actorId: user.id,
      actorRole: 'ADMIN',
      details: {}
    });
  };
  
  const handleRejectPartner = (partnerId: string) => {
    if (!user) return;
    rejectPartner(partnerId);
    addAuditLog({
      action: 'REJECT_PARTNER',
      entityType: 'PARTNER',
      entityId: partnerId,
      actorId: user.id,
      actorRole: 'ADMIN',
      details: {}
    });
  };
  
  const handleWalletTopup = () => {
    if (!selectedPartner || !walletAmount || !user) return;
    const amount = parseFloat(walletAmount);
    addWalletTransaction(selectedPartner.id, 'CREDIT', amount, walletNote || 'Admin top-up', undefined, user.id);
    addAuditLog({
      action: 'WALLET_TOPUP',
      entityType: 'PARTNER',
      entityId: selectedPartner.id,
      actorId: user.id,
      actorRole: 'ADMIN',
      details: { amount, note: walletNote }
    });
    setShowWalletModal(false);
    setSelectedPartner(null);
    setWalletAmount('');
    setWalletNote('');
  };
  
  const tabs = [
    { id: 'overview', label: 'Overview', icon: LayoutDashboard },
    { id: 'requests', label: 'Requests', icon: FileText },
    { id: 'partners', label: 'Partners', icon: Users },
    { id: 'services', label: 'Services', icon: Settings },
    { id: 'audit', label: 'Audit Logs', icon: Clock }
  ];
  
  // Demo: Enable admin role for testing
  React.useEffect(() => {
    if (user && user.role !== 'ADMIN') {
      setRole('ADMIN');
    }
  }, [user, setRole]);
  
  return (
    <div className="min-h-screen bg-bg animate-fade-in">
      <div className="flex">
        {/* Sidebar */}
        <aside className="w-64 bg-navy min-h-screen p-4 hidden lg:block">
          <div className="mb-8">
            <h2 className="text-white text-xl font-bold">Admin Panel</h2>
            <p className="text-gray-400 text-sm">Rajpal Solutions</p>
          </div>
          
          <nav className="space-y-2">
            {tabs.map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as TabType)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-colors ${
                  activeTab === tab.id
                    ? 'bg-saffron text-white'
                    : 'text-gray-300 hover:bg-white/10'
                }`}
              >
                <tab.icon className="w-5 h-5" />
                <span>{tab.label}</span>
              </button>
            ))}
          </nav>
        </aside>
        
        {/* Mobile Tabs */}
        <div className="lg:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 z-40">
          <div className="flex justify-around py-2">
            {tabs.slice(0, 4).map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as TabType)}
                className={`flex flex-col items-center gap-1 px-3 py-2 ${
                  activeTab === tab.id ? 'text-saffron' : 'text-gray-500'
                }`}
              >
                <tab.icon className="w-5 h-5" />
                <span className="text-xs">{tab.label}</span>
              </button>
            ))}
          </div>
        </div>
        
        {/* Main Content */}
        <main className="flex-1 p-8 pb-24 lg:pb-8">
          {/* Overview Tab */}
          {activeTab === 'overview' && (
            <div className="space-y-8">
              <div>
                <h1 className="text-2xl font-bold text-navy">Dashboard Overview</h1>
                <p className="text-gray-600">Monitor your platform performance</p>
              </div>
              
              {/* Stats Grid */}
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
                <Card className="bg-gradient-to-br from-blue-500 to-blue-600 text-white">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-blue-100 text-sm">Total Requests</p>
                      <p className="text-3xl font-bold mt-1">{stats.totalRequests}</p>
                    </div>
                    <FileText className="w-10 h-10 text-white/30" />
                  </div>
                </Card>
                
                <Card className="bg-gradient-to-br from-saffron to-saffron-dark text-white">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-orange-100 text-sm">Pending Review</p>
                      <p className="text-3xl font-bold mt-1">{stats.pendingRequests}</p>
                    </div>
                    <Clock className="w-10 h-10 text-white/30" />
                  </div>
                </Card>
                
                <Card className="bg-gradient-to-br from-green to-green-dark text-white">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-green-100 text-sm">Completed</p>
                      <p className="text-3xl font-bold mt-1">{stats.completedRequests}</p>
                    </div>
                    <CheckCircle className="w-10 h-10 text-white/30" />
                  </div>
                </Card>
                
                <Card className="bg-gradient-to-br from-purple-500 to-purple-600 text-white">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-purple-100 text-sm">Total Partners</p>
                      <p className="text-3xl font-bold mt-1">{stats.totalPartners}</p>
                    </div>
                    <Users className="w-10 h-10 text-white/30" />
                  </div>
                </Card>
                
                <Card className="bg-gradient-to-br from-yellow-500 to-yellow-600 text-white">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-yellow-100 text-sm">Pending Partners</p>
                      <p className="text-3xl font-bold mt-1">{stats.pendingPartners}</p>
                    </div>
                    <AlertCircle className="w-10 h-10 text-white/30" />
                  </div>
                </Card>
                
                <Card className="bg-gradient-to-br from-navy to-navy-light text-white">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-gray-300 text-sm">Total Revenue</p>
                      <p className="text-3xl font-bold mt-1">₹{stats.totalRevenue}</p>
                    </div>
                    <TrendingUp className="w-10 h-10 text-white/30" />
                  </div>
                </Card>
              </div>
              
              {/* Recent Activity */}
              <Card>
                <CardHeader title="Recent Requests" />
                <div className="space-y-3">
                  {requests.slice(0, 5).map(request => {
                    const service = services.find(s => s.id === request.serviceId);
                    return (
                      <div key={request.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-xl">
                        <div className="flex items-center gap-3">
                          <FileText className="w-5 h-5 text-saffron" />
                          <div>
                            <p className="font-medium text-navy">{service?.name}</p>
                            <p className="text-sm text-gray-500">ID: {request.id}</p>
                          </div>
                        </div>
                        <StatusBadge status={request.status} />
                      </div>
                    );
                  })}
                </div>
              </Card>
            </div>
          )}
          
          {/* Requests Tab */}
          {activeTab === 'requests' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h1 className="text-2xl font-bold text-navy">All Requests</h1>
                  <p className="text-gray-600">Manage service requests</p>
                </div>
                <div className="flex items-center gap-2">
                  <Input placeholder="Search..." icon={<Search className="w-4 h-4" />} />
                </div>
              </div>
              
              <Card>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="text-left px-4 py-3 text-sm font-medium text-gray-600">ID</th>
                        <th className="text-left px-4 py-3 text-sm font-medium text-gray-600">Service</th>
                        <th className="text-left px-4 py-3 text-sm font-medium text-gray-600">Status</th>
                        <th className="text-left px-4 py-3 text-sm font-medium text-gray-600">Payment</th>
                        <th className="text-left px-4 py-3 text-sm font-medium text-gray-600">Amount</th>
                        <th className="text-left px-4 py-3 text-sm font-medium text-gray-600">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100">
                      {requests.map(request => {
                        const service = services.find(s => s.id === request.serviceId);
                        return (
                          <tr key={request.id} className="hover:bg-gray-50">
                            <td className="px-4 py-3 text-sm font-mono">{request.id}</td>
                            <td className="px-4 py-3 text-sm">{service?.name}</td>
                            <td className="px-4 py-3"><StatusBadge status={request.status} /></td>
                            <td className="px-4 py-3 text-sm capitalize">{request.paymentStatus.toLowerCase()}</td>
                            <td className="px-4 py-3 text-sm font-semibold">₹{request.totalAmount}</td>
                            <td className="px-4 py-3">
                              <div className="flex items-center gap-2">
                                {!request.partnerId && request.status !== 'DRAFT' && (
                                  <Button 
                                    size="sm" 
                                    variant="outline"
                                    onClick={() => {
                                      setSelectedRequest(request);
                                      setShowAssignModal(true);
                                    }}
                                  >
                                    Assign
                                  </Button>
                                )}
                                <Button size="sm" variant="ghost">
                                  View
                                </Button>
                              </div>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </Card>
            </div>
          )}
          
          {/* Partners Tab */}
          {activeTab === 'partners' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h1 className="text-2xl font-bold text-navy">Partners</h1>
                  <p className="text-gray-600">Manage partner network</p>
                </div>
              </div>
              
              <div className="grid gap-6">
                {partners.map(partner => (
                  <Card key={partner.id}>
                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                      <div className="flex items-start gap-4">
                        <div className="w-12 h-12 bg-green/10 rounded-xl flex items-center justify-center">
                          <Users className="w-6 h-6 text-green" />
                        </div>
                        <div>
                          <h3 className="font-semibold text-navy">{partner.shopName}</h3>
                          <p className="text-sm text-gray-500">{partner.ownerName}</p>
                          <div className="flex items-center gap-4 mt-2 text-sm text-gray-500">
                            <span>Block: {partner.block}</span>
                            <span>Mobile: {partner.mobile}</span>
                            <span>Wallet: ₹{partner.walletBalance}</span>
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-3">
                        <VerificationBadge status={partner.verificationStatus} />
                        
                        {partner.verificationStatus === 'PENDING' && (
                          <>
                            <Button 
                              size="sm" 
                              variant="secondary"
                              onClick={() => handleApprovePartner(partner.id)}
                            >
                              <UserCheck className="w-4 h-4 mr-1" />
                              Approve
                            </Button>
                            <Button 
                              size="sm" 
                              variant="danger"
                              onClick={() => handleRejectPartner(partner.id)}
                            >
                              Reject
                            </Button>
                          </>
                        )}
                        
                        <Button 
                          size="sm" 
                          variant="outline"
                          onClick={() => {
                            setSelectedPartner(partner);
                            setShowWalletModal(true);
                          }}
                        >
                          <Wallet className="w-4 h-4 mr-1" />
                          Top-up
                        </Button>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            </div>
          )}
          
          {/* Services Tab */}
          {activeTab === 'services' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h1 className="text-2xl font-bold text-navy">Services</h1>
                  <p className="text-gray-600">Manage service catalog</p>
                </div>
                <Button icon={<Plus className="w-4 h-4" />}>
                  Add Service
                </Button>
              </div>
              
              <Card>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="text-left px-4 py-3 text-sm font-medium text-gray-600">Service</th>
                        <th className="text-left px-4 py-3 text-sm font-medium text-gray-600">Category</th>
                        <th className="text-left px-4 py-3 text-sm font-medium text-gray-600">Price</th>
                        <th className="text-left px-4 py-3 text-sm font-medium text-gray-600">Delivery Fee</th>
                        <th className="text-left px-4 py-3 text-sm font-medium text-gray-600">Status</th>
                        <th className="text-left px-4 py-3 text-sm font-medium text-gray-600">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100">
                      {services.map(service => (
                        <tr key={service.id} className="hover:bg-gray-50">
                          <td className="px-4 py-3">
                            <div>
                              <p className="font-medium text-navy">{service.name}</p>
                              <p className="text-sm text-gray-500">{service.nameHi}</p>
                            </div>
                          </td>
                          <td className="px-4 py-3 text-sm capitalize">{service.categoryId}</td>
                          <td className="px-4 py-3 text-sm font-semibold">₹{service.price}</td>
                          <td className="px-4 py-3 text-sm">₹{service.deliveryFee}</td>
                          <td className="px-4 py-3">
                            <span className={`px-2 py-1 text-xs rounded-full ${
                              service.isActive 
                                ? 'bg-green/10 text-green' 
                                : 'bg-red-100 text-red-600'
                            }`}>
                              {service.isActive ? 'Active' : 'Inactive'}
                            </span>
                          </td>
                          <td className="px-4 py-3">
                            <Button size="sm" variant="ghost">Edit</Button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </Card>
            </div>
          )}
          
          {/* Audit Logs Tab */}
          {activeTab === 'audit' && (
            <div className="space-y-6">
              <div>
                <h1 className="text-2xl font-bold text-navy">Audit Logs</h1>
                <p className="text-gray-600">Track all admin actions</p>
              </div>
              
              <Card>
                {auditLogs.length > 0 ? (
                  <div className="space-y-3">
                    {auditLogs.map(log => (
                      <div key={log.id} className="flex items-start gap-4 p-3 bg-gray-50 rounded-xl">
                        <div className="w-10 h-10 bg-navy/10 rounded-lg flex items-center justify-center shrink-0">
                          <Settings className="w-5 h-5 text-navy" />
                        </div>
                        <div className="flex-1">
                          <p className="font-medium text-navy">{log.action}</p>
                          <p className="text-sm text-gray-500">
                            {log.entityType}: {log.entityId}
                          </p>
                          <p className="text-xs text-gray-400 mt-1">
                            {new Date(log.createdAt).toLocaleString()}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <Clock className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                    <p className="text-gray-600">No audit logs yet</p>
                  </div>
                )}
              </Card>
            </div>
          )}
        </main>
      </div>
      
      {/* Assign Partner Modal */}
      <Modal
        isOpen={showAssignModal}
        onClose={() => setShowAssignModal(false)}
        title="Assign Partner"
        size="md"
      >
        <p className="text-gray-600 mb-4">
          Select a partner to assign this request to:
        </p>
        <div className="space-y-3">
          {partners.filter(p => p.verificationStatus === 'APPROVED').map(partner => (
            <button
              key={partner.id}
              onClick={() => handleAssignPartner(partner.id)}
              className="w-full flex items-center justify-between p-4 border border-gray-200 rounded-xl hover:border-saffron hover:bg-saffron/5 transition-colors"
            >
              <div className="text-left">
                <p className="font-medium text-navy">{partner.shopName}</p>
                <p className="text-sm text-gray-500">{partner.block} • {partner.mobile}</p>
              </div>
              <ArrowRight className="w-5 h-5 text-gray-400" />
            </button>
          ))}
        </div>
      </Modal>
      
      {/* Wallet Top-up Modal */}
      <Modal
        isOpen={showWalletModal}
        onClose={() => setShowWalletModal(false)}
        title="Wallet Top-up"
        size="sm"
      >
        <div className="space-y-4">
          <p className="text-gray-600">
            Add funds to {selectedPartner?.shopName}'s wallet
          </p>
          <p className="text-sm text-gray-500">
            Current Balance: <span className="font-semibold">₹{selectedPartner?.walletBalance}</span>
          </p>
          <Input
            label="Amount"
            type="number"
            placeholder="Enter amount"
            value={walletAmount}
            onChange={(e) => setWalletAmount(e.target.value)}
          />
          <Input
            label="Note (optional)"
            placeholder="Reason for top-up"
            value={walletNote}
            onChange={(e) => setWalletNote(e.target.value)}
          />
          <Button 
            className="w-full"
            onClick={handleWalletTopup}
            disabled={!walletAmount || parseFloat(walletAmount) <= 0}
          >
            Add ₹{walletAmount || '0'} to Wallet
          </Button>
        </div>
      </Modal>
    </div>
  );
};
