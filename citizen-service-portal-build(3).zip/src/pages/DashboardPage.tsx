import React from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  FileText, 
  Clock, 
  CheckCircle, 
  AlertCircle,
  ArrowRight,
  Plus,
  TrendingUp,
  User
} from 'lucide-react';
import { Card, CardHeader } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { StatusBadge } from '@/components/ui/Badge';
import { useAuthStore, useRequestStore } from '@/store';
import { services } from '@/data/services';

export const DashboardPage: React.FC = () => {
  const navigate = useNavigate();
  const { user } = useAuthStore();
  const { getRequestsByUser } = useRequestStore();
  
  const userRequests = user ? getRequestsByUser(user.id) : [];
  
  const stats = {
    total: userRequests.length,
    pending: userRequests.filter(r => ['SUBMITTED', 'IN_REVIEW', 'PROCESSING', 'ASSIGNED'].includes(r.status)).length,
    completed: userRequests.filter(r => r.status === 'COMPLETED').length,
    draft: userRequests.filter(r => r.status === 'DRAFT').length
  };
  
  const recentRequests = userRequests.slice(0, 5);
  
  return (
    <div className="min-h-screen bg-bg py-8 animate-fade-in">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h1 className="text-2xl font-bold text-navy">
                Welcome, {user?.name || 'User'}! 👋
              </h1>
              <p className="text-gray-600">
                Track your service requests and manage your applications
              </p>
            </div>
            <Button 
              onClick={() => navigate('/services')}
              icon={<Plus className="w-4 h-4" />}
            >
              New Request
            </Button>
          </div>
        </div>
        
        {/* Stats Cards */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="bg-gradient-to-br from-blue-500 to-blue-600 text-white">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-blue-100 text-sm">Total Requests</p>
                <p className="text-3xl font-bold mt-1">{stats.total}</p>
              </div>
              <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
                <FileText className="w-6 h-6" />
              </div>
            </div>
          </Card>
          
          <Card className="bg-gradient-to-br from-saffron to-saffron-dark text-white">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-orange-100 text-sm">In Progress</p>
                <p className="text-3xl font-bold mt-1">{stats.pending}</p>
              </div>
              <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
                <Clock className="w-6 h-6" />
              </div>
            </div>
          </Card>
          
          <Card className="bg-gradient-to-br from-green to-green-dark text-white">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-green-100 text-sm">Completed</p>
                <p className="text-3xl font-bold mt-1">{stats.completed}</p>
              </div>
              <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
                <CheckCircle className="w-6 h-6" />
              </div>
            </div>
          </Card>
          
          <Card className="bg-gradient-to-br from-gray-600 to-gray-700 text-white">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-300 text-sm">Drafts</p>
                <p className="text-3xl font-bold mt-1">{stats.draft}</p>
              </div>
              <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
                <AlertCircle className="w-6 h-6" />
              </div>
            </div>
          </Card>
        </div>
        
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Recent Requests */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader 
                title="Recent Requests" 
                subtitle="Your latest service applications"
                action={
                  <Button 
                    variant="ghost" 
                    size="sm"
                    onClick={() => navigate('/my-requests')}
                  >
                    View All <ArrowRight className="w-4 h-4 ml-1" />
                  </Button>
                }
              />
              
              {recentRequests.length > 0 ? (
                <div className="space-y-4">
                  {recentRequests.map(request => {
                    const service = services.find(s => s.id === request.serviceId);
                    return (
                      <div 
                        key={request.id}
                        onClick={() => navigate(`/request/${request.id}`)}
                        className="flex items-center justify-between p-4 bg-gray-50 rounded-xl hover:bg-gray-100 cursor-pointer transition-colors"
                      >
                        <div className="flex items-center gap-4">
                          <div className="w-10 h-10 bg-saffron/10 rounded-lg flex items-center justify-center">
                            <FileText className="w-5 h-5 text-saffron" />
                          </div>
                          <div>
                            <p className="font-medium text-navy">{service?.name || 'Unknown Service'}</p>
                            <p className="text-sm text-gray-500">
                              ID: {request.id} • {new Date(request.createdAt).toLocaleDateString()}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center gap-3">
                          <StatusBadge status={request.status} />
                          <ArrowRight className="w-4 h-4 text-gray-400" />
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="text-center py-12">
                  <FileText className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                  <p className="text-gray-600 mb-4">No requests yet</p>
                  <Button onClick={() => navigate('/services')}>
                    Browse Services
                  </Button>
                </div>
              )}
            </Card>
          </div>
          
          {/* Quick Actions & Profile */}
          <div className="space-y-6">
            {/* Profile Card */}
            <Card>
              <div className="flex items-center gap-4 mb-6">
                <div className="w-16 h-16 bg-saffron/10 rounded-full flex items-center justify-center">
                  <User className="w-8 h-8 text-saffron" />
                </div>
                <div>
                  <p className="font-semibold text-navy">{user?.name || 'User'}</p>
                  <p className="text-sm text-gray-500">{user?.mobile}</p>
                  <span className="inline-block px-2 py-0.5 bg-saffron/10 text-saffron text-xs rounded-full mt-1">
                    {user?.role}
                  </span>
                </div>
              </div>
              <Button 
                variant="outline" 
                className="w-full"
                onClick={() => navigate('/settings')}
              >
                Edit Profile
              </Button>
            </Card>
            
            {/* Quick Actions */}
            <Card>
              <CardHeader title="Quick Actions" />
              <div className="space-y-3">
                <button 
                  onClick={() => navigate('/services?category=pan')}
                  className="w-full flex items-center gap-3 p-3 rounded-xl hover:bg-gray-50 transition-colors text-left"
                >
                  <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                    <FileText className="w-5 h-5 text-blue-600" />
                  </div>
                  <span className="font-medium text-navy">Apply for PAN Card</span>
                </button>
                
                <button 
                  onClick={() => navigate('/services?category=certificates')}
                  className="w-full flex items-center gap-3 p-3 rounded-xl hover:bg-gray-50 transition-colors text-left"
                >
                  <div className="w-10 h-10 bg-green/10 rounded-lg flex items-center justify-center">
                    <CheckCircle className="w-5 h-5 text-green" />
                  </div>
                  <span className="font-medium text-navy">Get Certificates</span>
                </button>
                
                <button 
                  onClick={() => navigate('/track')}
                  className="w-full flex items-center gap-3 p-3 rounded-xl hover:bg-gray-50 transition-colors text-left"
                >
                  <div className="w-10 h-10 bg-saffron/10 rounded-lg flex items-center justify-center">
                    <TrendingUp className="w-5 h-5 text-saffron" />
                  </div>
                  <span className="font-medium text-navy">Track Request</span>
                </button>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};
