import React from 'react';
import { Link } from 'react-router-dom';
import { MapPin, Phone, Globe, Mail, Facebook, Instagram, Youtube } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-navy text-white">
      {/* Main Footer */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 bg-gradient-to-br from-saffron to-saffron-dark rounded-xl flex items-center justify-center">
                <span className="text-white font-bold text-xl">R</span>
              </div>
              <div>
                <h3 className="text-xl font-bold">Rajpal Solutions</h3>
                <p className="text-sm text-gray-400">सरकारी सेवा पोर्टल</p>
              </div>
            </div>
            <p className="text-gray-400 text-sm mb-4 hindi-text">
              "Aap ham tak pahunchiye, ham samadhaan tak pahunchaa denge."
            </p>
            <p className="text-saffron font-medium hindi-text">
              "Ab aap nischint rahiye, ham chintaa karenge."
            </p>
          </div>
          
          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2">
              <li>
                <Link to="/services" className="text-gray-400 hover:text-white transition-colors">
                  All Services
                </Link>
              </li>
              <li>
                <Link to="/track" className="text-gray-400 hover:text-white transition-colors">
                  Track Request
                </Link>
              </li>
              <li>
                <Link to="/partner-register" className="text-gray-400 hover:text-white transition-colors">
                  Become a Partner
                </Link>
              </li>
              <li>
                <Link to="/about" className="text-gray-400 hover:text-white transition-colors">
                  About Us
                </Link>
              </li>
            </ul>
          </div>
          
          {/* Services */}
          <div>
            <h4 className="text-lg font-semibold mb-4">Popular Services</h4>
            <ul className="space-y-2">
              <li>
                <Link to="/services?category=pan" className="text-gray-400 hover:text-white transition-colors">
                  PAN Card Services
                </Link>
              </li>
              <li>
                <Link to="/services?category=certificates" className="text-gray-400 hover:text-white transition-colors">
                  Certificates
                </Link>
              </li>
              <li>
                <Link to="/services?category=land" className="text-gray-400 hover:text-white transition-colors">
                  Land Records
                </Link>
              </li>
              <li>
                <Link to="/services?category=welfare" className="text-gray-400 hover:text-white transition-colors">
                  Welfare Schemes
                </Link>
              </li>
            </ul>
          </div>
          
          {/* Contact */}
          <div>
            <h4 className="text-lg font-semibold mb-4">Contact Us</h4>
            <ul className="space-y-3">
              <li className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-saffron shrink-0 mt-0.5" />
                <span className="text-gray-400 text-sm">
                  In front of District Collectorate,<br />
                  Maharana Pratap Chouraha,<br />
                  Jabalpur Naka, Damoh 470661
                </span>
              </li>
              <li className="flex items-center gap-3">
                <Phone className="w-5 h-5 text-saffron shrink-0" />
                <div className="text-gray-400 text-sm">
                  <a href="tel:8269342506" className="hover:text-white transition-colors">8269342506</a>
                  {', '}
                  <a href="tel:8085227600" className="hover:text-white transition-colors">8085227600</a>
                </div>
              </li>
              <li className="flex items-center gap-3">
                <Globe className="w-5 h-5 text-saffron shrink-0" />
                <a href="https://rajpalsolutions.in" className="text-gray-400 hover:text-white transition-colors text-sm">
                  Rajpalsolutions.in
                </a>
              </li>
              <li className="flex items-center gap-3">
                <Mail className="w-5 h-5 text-saffron shrink-0" />
                <a href="mailto:contact@rajpalsolutions.in" className="text-gray-400 hover:text-white transition-colors text-sm">
                  contact@rajpalsolutions.in
                </a>
              </li>
            </ul>
            
            {/* Social */}
            <div className="flex items-center gap-4 mt-4">
              <a href="#" className="p-2 bg-navy-light rounded-full hover:bg-saffron transition-colors">
                <Facebook className="w-5 h-5" />
              </a>
              <a href="#" className="p-2 bg-navy-light rounded-full hover:bg-saffron transition-colors">
                <Instagram className="w-5 h-5" />
              </a>
              <a href="#" className="p-2 bg-navy-light rounded-full hover:bg-saffron transition-colors">
                <Youtube className="w-5 h-5" />
              </a>
            </div>
          </div>
        </div>
      </div>
      
      {/* Bottom Bar */}
      <div className="border-t border-navy-light">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <p className="text-gray-400 text-sm">
              © {new Date().getFullYear()} Rajpal Solutions. All rights reserved.
            </p>
            <div className="flex items-center gap-4 text-sm">
              <Link to="/privacy" className="text-gray-400 hover:text-white transition-colors">
                Privacy Policy
              </Link>
              <Link to="/terms" className="text-gray-400 hover:text-white transition-colors">
                Terms of Service
              </Link>
              <Link to="/refund" className="text-gray-400 hover:text-white transition-colors">
                Refund Policy
              </Link>
            </div>
          </div>
        </div>
      </div>
      
      {/* Tricolor stripe */}
      <div className="tricolor-stripe" />
    </footer>
  );
};
