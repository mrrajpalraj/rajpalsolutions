import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { 
  Menu, 
  X, 
  Phone, 
  User, 
  LogOut, 
  ChevronDown,
  LayoutDashboard,
  Settings,
  FileText
} from 'lucide-react';
import { useAuthStore, useUIStore } from '@/store';
import { Button } from '@/components/ui/Button';

export const Header: React.FC = () => {
  const { user, isAuthenticated, logout } = useAuthStore();
  const { language, setLanguage } = useUIStore();
  const navigate = useNavigate();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  
  const handleLogout = () => {
    logout();
    navigate('/');
    setUserMenuOpen(false);
  };
  
  return (
    <>
      {/* Tricolor stripe */}
      <div className="tricolor-stripe" />
      
      <header className="bg-white shadow-sm sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <Link to="/" className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-saffron to-saffron-dark rounded-xl flex items-center justify-center shadow-lg">
                <span className="text-white font-bold text-lg">R</span>
              </div>
              <div className="hidden sm:block">
                <h1 className="text-lg font-bold text-navy">Rajpal Solutions</h1>
                <p className="text-xs text-gray-500 -mt-0.5">सरकारी सेवा पोर्टल</p>
              </div>
            </Link>
            
            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center gap-6">
              <Link 
                to="/services" 
                className="text-gray-600 hover:text-navy font-medium transition-colors"
              >
                Services
              </Link>
              <Link 
                to="/track" 
                className="text-gray-600 hover:text-navy font-medium transition-colors"
              >
                Track Request
              </Link>
              <Link 
                to="/contact" 
                className="text-gray-600 hover:text-navy font-medium transition-colors"
              >
                Contact
              </Link>
            </nav>
            
            {/* Right side */}
            <div className="flex items-center gap-3">
              {/* Language Toggle */}
              <button
                onClick={() => setLanguage(language === 'en' ? 'hi' : 'en')}
                className="hidden sm:flex items-center gap-1 px-3 py-1.5 text-sm font-medium text-gray-600 hover:text-navy border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
              >
                {language === 'en' ? 'हिंदी' : 'EN'}
              </button>
              
              {/* Phone */}
              <a 
                href="tel:8269342506" 
                className="hidden lg:flex items-center gap-2 text-green font-medium"
              >
                <Phone className="w-4 h-4" />
                <span>8269342506</span>
              </a>
              
              {isAuthenticated && user ? (
                <div className="relative">
                  <button
                    onClick={() => setUserMenuOpen(!userMenuOpen)}
                    className="flex items-center gap-2 px-3 py-2 bg-gray-50 hover:bg-gray-100 rounded-xl transition-colors"
                  >
                    <div className="w-8 h-8 bg-saffron rounded-full flex items-center justify-center">
                      <User className="w-4 h-4 text-white" />
                    </div>
                    <span className="hidden sm:block text-sm font-medium text-navy">
                      {user.name || user.mobile}
                    </span>
                    <ChevronDown className="w-4 h-4 text-gray-400" />
                  </button>
                  
                  {userMenuOpen && (
                    <div className="absolute right-0 mt-2 w-56 bg-white rounded-xl shadow-lg border border-gray-100 py-2 animate-fade-in">
                      <div className="px-4 py-2 border-b border-gray-100">
                        <p className="text-sm font-medium text-navy">{user.name || 'User'}</p>
                        <p className="text-xs text-gray-500">{user.mobile}</p>
                        <p className="text-xs text-saffron font-medium mt-1">{user.role}</p>
                      </div>
                      
                      <Link
                        to={user.role === 'ADMIN' ? '/admin' : user.role === 'PARTNER' ? '/partner' : '/dashboard'}
                        onClick={() => setUserMenuOpen(false)}
                        className="flex items-center gap-3 px-4 py-2 text-gray-700 hover:bg-gray-50 transition-colors"
                      >
                        <LayoutDashboard className="w-4 h-4" />
                        <span>Dashboard</span>
                      </Link>
                      
                      <Link
                        to="/my-requests"
                        onClick={() => setUserMenuOpen(false)}
                        className="flex items-center gap-3 px-4 py-2 text-gray-700 hover:bg-gray-50 transition-colors"
                      >
                        <FileText className="w-4 h-4" />
                        <span>My Requests</span>
                      </Link>
                      
                      <Link
                        to="/settings"
                        onClick={() => setUserMenuOpen(false)}
                        className="flex items-center gap-3 px-4 py-2 text-gray-700 hover:bg-gray-50 transition-colors"
                      >
                        <Settings className="w-4 h-4" />
                        <span>Settings</span>
                      </Link>
                      
                      <hr className="my-2 border-gray-100" />
                      
                      <button
                        onClick={handleLogout}
                        className="flex items-center gap-3 px-4 py-2 text-red-600 hover:bg-red-50 transition-colors w-full"
                      >
                        <LogOut className="w-4 h-4" />
                        <span>Logout</span>
                      </button>
                    </div>
                  )}
                </div>
              ) : (
                <Button 
                  onClick={() => navigate('/login')}
                  size="sm"
                >
                  Login
                </Button>
              )}
              
              {/* Mobile menu button */}
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="md:hidden p-2 text-gray-600 hover:text-navy"
              >
                {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>
        
        {/* Mobile menu */}
        {mobileMenuOpen && (
          <div className="md:hidden bg-white border-t border-gray-100 animate-fade-in">
            <nav className="px-4 py-4 space-y-2">
              <Link 
                to="/services"
                onClick={() => setMobileMenuOpen(false)}
                className="block px-4 py-3 text-gray-700 hover:bg-gray-50 rounded-xl font-medium"
              >
                Services
              </Link>
              <Link 
                to="/track"
                onClick={() => setMobileMenuOpen(false)}
                className="block px-4 py-3 text-gray-700 hover:bg-gray-50 rounded-xl font-medium"
              >
                Track Request
              </Link>
              <Link 
                to="/contact"
                onClick={() => setMobileMenuOpen(false)}
                className="block px-4 py-3 text-gray-700 hover:bg-gray-50 rounded-xl font-medium"
              >
                Contact
              </Link>
              <a 
                href="tel:8269342506"
                className="flex items-center gap-2 px-4 py-3 text-green font-medium"
              >
                <Phone className="w-4 h-4" />
                <span>8269342506</span>
              </a>
            </nav>
          </div>
        )}
      </header>
    </>
  );
};
