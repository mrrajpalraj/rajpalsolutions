import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { 
  ArrowLeft, 
  FileText, 
  Clock, 
  CheckCircle, 
  User,
  MapPin,
  Phone,
  Download,
  MessageSquare,
  AlertCircle,
  Truck,
  Store,
  Monitor
} from 'lucide-react';
import { Card, CardHeader } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { StatusBadge, PaymentBadge } from '@/components/ui/Badge';
import { useRequestStore, usePartnerStore } from '@/store';
import { services } from '@/data/services';
import { RequestStatus } from '@/types';

const statusTimeline: { status: RequestStatus; label: string }[] = [
  { status: 'SUBMITTED', label: 'Submitted' },
  { status: 'IN_REVIEW', label: 'In Review' },
  { status: 'ASSIGNED', label: 'Assigned' },
  { status: 'PROCESSING', label: 'Processing' },
  { status: 'READY', label: 'Ready' },
  { status: 'COMPLETED', label: 'Completed' }
];

export const RequestDetailPage: React.FC = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { getRequestById, getStatusEvents } = useRequestStore();
  const { getPartnerById } = usePartnerStore();
  
  const request = getRequestById(id || '');
  const statusEvents = getStatusEvents(id || '');
  const service = services.find(s => s.id === request?.serviceId);
  const partner = request?.partnerId ? getPartnerById(request.partnerId) : null;
  
  if (!request || !service) {
    return (
      <div className="min-h-screen bg-bg flex items-center justify-center">
        <Card className="text-center p-8">
          <AlertCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
          <h2 className="text-xl font-bold text-navy mb-2">Request Not Found</h2>
          <p className="text-gray-600 mb-4">The requested application could not be found.</p>
          <Button onClick={() => navigate('/my-requests')}>View My Requests</Button>
        </Card>
      </div>
    );
  }
  
  const currentStatusIndex = statusTimeline.findIndex(s => s.status === request.status);
  
  const getFulfillmentIcon = () => {
    switch (request.fulfillmentMethod) {
      case 'DIGITAL_ONLY': return <Monitor className="w-5 h-5" />;
      case 'PARTNER_PICKUP': return <Store className="w-5 h-5" />;
      case 'HOME_DELIVERY': return <Truck className="w-5 h-5" />;
    }
  };
  
  return (
    <div className="min-h-screen bg-bg py-8 animate-fade-in">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <button
            onClick={() => navigate(-1)}
            className="flex items-center gap-2 text-gray-600 hover:text-navy mb-4"
          >
            <ArrowLeft className="w-4 h-4" />
            Back
          </button>
          
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h1 className="text-2xl font-bold text-navy">{service.name}</h1>
              <p className="text-gray-500 font-mono">Request ID: {request.id}</p>
            </div>
            <div className="flex items-center gap-3">
              <StatusBadge status={request.status} />
              <PaymentBadge status={request.paymentStatus} />
            </div>
          </div>
        </div>
        
        {/* Status Timeline */}
        <Card className="mb-6">
          <CardHeader title="Status Timeline" subtitle="Track your application progress" />
          <div className="relative">
            <div className="flex items-center justify-between">
              {statusTimeline.map((item, idx) => {
                const isCompleted = currentStatusIndex >= idx;
                const isCurrent = currentStatusIndex === idx;
                
                return (
                  <div key={item.status} className="flex-1 flex flex-col items-center relative">
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center z-10 ${
                      isCompleted 
                        ? 'bg-green text-white' 
                        : 'bg-gray-200 text-gray-400'
                    } ${isCurrent ? 'ring-4 ring-green/30' : ''}`}>
                      {isCompleted ? (
                        <CheckCircle className="w-5 h-5" />
                      ) : (
                        <Clock className="w-5 h-5" />
                      )}
                    </div>
                    <span className={`text-xs mt-2 text-center ${
                      isCompleted ? 'text-green font-medium' : 'text-gray-400'
                    }`}>
                      {item.label}
                    </span>
                    
                    {idx < statusTimeline.length - 1 && (
                      <div className={`absolute top-5 left-[55%] w-full h-0.5 ${
                        currentStatusIndex > idx ? 'bg-green' : 'bg-gray-200'
                      }`} />
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </Card>
        
        <div className="grid lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            {/* Application Details */}
            <Card>
              <CardHeader title="Application Details" />
              <div className="grid gap-3">
                {Object.entries(request.formData).map(([key, value]) => (
                  <div key={key} className="flex justify-between py-2 border-b border-gray-100 last:border-0">
                    <span className="text-gray-600 capitalize">{key.replace(/_/g, ' ')}</span>
                    <span className="font-medium text-navy">{String(value)}</span>
                  </div>
                ))}
              </div>
            </Card>
            
            {/* Uploaded Documents */}
            <Card>
              <CardHeader title="Uploaded Documents" />
              <div className="grid gap-3 sm:grid-cols-2">
                {request.uploads.map(upload => (
                  <div 
                    key={upload.id} 
                    className="flex items-center justify-between p-3 bg-gray-50 rounded-xl"
                  >
                    <div className="flex items-center gap-3">
                      <FileText className="w-5 h-5 text-saffron" />
                      <div>
                        <p className="font-medium text-navy capitalize">{upload.tag.replace(/_/g, ' ')}</p>
                        <p className="text-xs text-gray-500">{upload.fileName}</p>
                      </div>
                    </div>
                    <button className="p-2 text-gray-400 hover:text-saffron">
                      <Download className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            </Card>
            
            {/* Status History */}
            <Card>
              <CardHeader title="Activity Log" />
              <div className="space-y-4">
                {statusEvents.map((event, idx) => (
                  <div key={event.id} className="flex gap-4">
                    <div className="flex flex-col items-center">
                      <div className={`w-3 h-3 rounded-full ${
                        idx === 0 ? 'bg-saffron' : 'bg-gray-300'
                      }`} />
                      {idx < statusEvents.length - 1 && (
                        <div className="w-0.5 h-full bg-gray-200 mt-1" />
                      )}
                    </div>
                    <div className="flex-1 pb-4">
                      <p className="font-medium text-navy">{event.status.replace(/_/g, ' ')}</p>
                      {event.note && <p className="text-sm text-gray-600">{event.note}</p>}
                      <p className="text-xs text-gray-400 mt-1">
                        {new Date(event.createdAt).toLocaleString()}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </div>
          
          {/* Sidebar */}
          <div className="space-y-6">
            {/* Payment Summary */}
            <Card>
              <CardHeader title="Payment Details" />
              <div className="space-y-3">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Service Fee</span>
                  <span className="font-medium">₹{service.price}</span>
                </div>
                {request.fulfillmentMethod === 'HOME_DELIVERY' && (
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Delivery Fee</span>
                    <span className="font-medium">₹{service.deliveryFee}</span>
                  </div>
                )}
                <div className="border-t border-gray-100 pt-3 flex justify-between">
                  <span className="font-semibold text-navy">Total</span>
                  <span className="font-bold text-xl text-saffron">₹{request.totalAmount}</span>
                </div>
                <div className="pt-2">
                  <span className="text-sm text-gray-500">Payment Mode: </span>
                  <span className="text-sm font-medium text-navy">
                    {request.paymentMode === 'ONLINE' ? 'Online' : 'Pay at Partner'}
                  </span>
                </div>
              </div>
            </Card>
            
            {/* Delivery Info */}
            <Card>
              <CardHeader title="Delivery Method" />
              <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-xl">
                <div className="w-10 h-10 bg-saffron/10 rounded-lg flex items-center justify-center text-saffron">
                  {getFulfillmentIcon()}
                </div>
                <div>
                  <p className="font-medium text-navy capitalize">
                    {request.fulfillmentMethod.replace(/_/g, ' ').toLowerCase()}
                  </p>
                  {request.deliveryStatus && (
                    <p className="text-sm text-gray-500">
                      Status: {request.deliveryStatus}
                    </p>
                  )}
                </div>
              </div>
              
              {request.deliveryAddress && (
                <div className="mt-4 p-3 bg-blue-50 rounded-xl">
                  <p className="text-sm font-medium text-navy flex items-center gap-2">
                    <MapPin className="w-4 h-4" />
                    Delivery Address
                  </p>
                  <p className="text-sm text-gray-600 mt-1">
                    {request.deliveryAddress.name}<br />
                    {request.deliveryAddress.addressLine1}<br />
                    {request.deliveryAddress.city}, {request.deliveryAddress.district}<br />
                    {request.deliveryAddress.state} - {request.deliveryAddress.pincode}
                  </p>
                </div>
              )}
            </Card>
            
            {/* Assigned Partner */}
            {partner && (
              <Card>
                <CardHeader title="Assigned Partner" />
                <div className="flex items-start gap-3">
                  <div className="w-12 h-12 bg-green/10 rounded-xl flex items-center justify-center">
                    <User className="w-6 h-6 text-green" />
                  </div>
                  <div>
                    <p className="font-medium text-navy">{partner.shopName}</p>
                    <p className="text-sm text-gray-500">{partner.ownerName}</p>
                    <div className="flex items-center gap-2 mt-2 text-sm text-gray-600">
                      <Phone className="w-4 h-4" />
                      <a href={`tel:${partner.mobile}`} className="hover:text-saffron">
                        {partner.mobile}
                      </a>
                    </div>
                    <div className="flex items-center gap-2 mt-1 text-sm text-gray-600">
                      <MapPin className="w-4 h-4" />
                      {partner.address}
                    </div>
                  </div>
                </div>
              </Card>
            )}
            
            {/* Actions */}
            <Card>
              <CardHeader title="Need Help?" />
              <div className="space-y-3">
                <Button variant="outline" className="w-full" icon={<MessageSquare className="w-4 h-4" />}>
                  Contact Support
                </Button>
                <Button variant="ghost" className="w-full" icon={<Download className="w-4 h-4" />}>
                  Download Receipt
                </Button>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};
