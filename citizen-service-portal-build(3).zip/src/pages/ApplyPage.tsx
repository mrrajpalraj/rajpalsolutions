import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { 
  ArrowLeft, 
  ArrowRight, 
  Check, 
  Upload, 
  X, 
  CreditCard,
  MapPin,
  Truck,
  Store,
  Monitor,
  AlertCircle,
  CheckCircle
} from 'lucide-react';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Input, Select, Textarea } from '@/components/ui/Input';
import { Modal } from '@/components/ui/Modal';
import { services } from '@/data/services';
import { useAuthStore, useRequestStore } from '@/store';
import { FormField, UploadField, FulfillmentMethod, PaymentMode } from '@/types';

export const ApplyPage: React.FC = () => {
  const { serviceId } = useParams();
  const navigate = useNavigate();
  const { user, isAuthenticated } = useAuthStore();
  const { createRequest } = useRequestStore();
  
  const service = services.find(s => s.id === serviceId);
  
  const [currentStep, setCurrentStep] = useState(0);
  const [formData, setFormData] = useState<Record<string, any>>({});
  const [uploads, setUploads] = useState<Record<string, File>>({});
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [consentGiven, setConsentGiven] = useState(false);
  const [fulfillmentMethod, setFulfillmentMethod] = useState<FulfillmentMethod>('PARTNER_PICKUP');
  const [paymentMode, setPaymentMode] = useState<PaymentMode>('ONLINE');
  const [deliveryAddress, setDeliveryAddress] = useState({
    name: '',
    mobile: '',
    addressLine1: '',
    addressLine2: '',
    city: '',
    district: 'Damoh',
    state: 'Madhya Pradesh',
    pincode: ''
  });
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [processing, setProcessing] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [submittedRequestId, setSubmittedRequestId] = useState<string | null>(null);
  
  if (!service) {
    return (
      <div className="min-h-screen bg-bg flex items-center justify-center">
        <Card className="text-center p-8">
          <AlertCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
          <h2 className="text-xl font-bold text-navy mb-2">Service Not Found</h2>
          <p className="text-gray-600 mb-4">The requested service does not exist.</p>
          <Button onClick={() => navigate('/services')}>Browse Services</Button>
        </Card>
      </div>
    );
  }
  
  const schema = service.formSchema;
  const totalSteps = schema.steps.length + 2; // +2 for fulfillment and review
  
  const calculateTotal = () => {
    let total = service.price;
    if (fulfillmentMethod === 'HOME_DELIVERY') {
      total += service.deliveryFee;
    }
    return total;
  };
  
  const validateStep = (stepIndex: number): boolean => {
    const step = schema.steps[stepIndex];
    if (!step) return true;
    
    const newErrors: Record<string, string> = {};
    
    if (step.fields) {
      step.fields.forEach(field => {
        if (field.required && !formData[field.key]) {
          newErrors[field.key] = `${field.label} is required`;
        }
        if (formData[field.key] && field.validation?.pattern) {
          const regex = new RegExp(field.validation.pattern);
          if (!regex.test(formData[field.key])) {
            newErrors[field.key] = `Invalid ${field.label.toLowerCase()}`;
          }
        }
      });
    }
    
    if (step.uploads) {
      step.uploads.forEach(upload => {
        if (upload.required && !uploads[upload.tag]) {
          newErrors[upload.tag] = `${upload.label} is required`;
        }
      });
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  
  const handleNext = () => {
    if (currentStep < schema.steps.length) {
      if (!validateStep(currentStep)) return;
    }
    
    if (currentStep < totalSteps - 1) {
      setCurrentStep(prev => prev + 1);
    }
  };
  
  const handlePrev = () => {
    if (currentStep > 0) {
      setCurrentStep(prev => prev - 1);
    }
  };
  
  const handleFieldChange = (key: string, value: any) => {
    setFormData(prev => ({ ...prev, [key]: value }));
    if (errors[key]) {
      setErrors(prev => {
        const { [key]: _, ...rest } = prev;
        return rest;
      });
    }
  };
  
  const handleFileChange = (tag: string, file: File | null) => {
    if (file) {
      setUploads(prev => ({ ...prev, [tag]: file }));
      if (errors[tag]) {
        setErrors(prev => {
          const { [tag]: _, ...rest } = prev;
          return rest;
        });
      }
    } else {
      setUploads(prev => {
        const { [tag]: _, ...rest } = prev;
        return rest;
      });
    }
  };
  
  const handleSubmit = async () => {
    if (!isAuthenticated || !user) {
      navigate('/login', { state: { from: `/apply/${serviceId}` } });
      return;
    }
    
    if (!consentGiven) {
      setErrors({ consent: 'Please provide your consent to proceed' });
      return;
    }
    
    setShowPaymentModal(true);
  };
  
  const processPayment = async () => {
    setProcessing(true);
    
    // Simulate payment processing
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // Create the request
    const uploadedFiles = Object.entries(uploads).map(([tag, file]) => ({
      id: Math.random().toString(36).substr(2, 9),
      tag,
      fileName: file.name,
      fileUrl: URL.createObjectURL(file),
      uploadedAt: new Date().toISOString()
    }));
    
    const request = createRequest({
      userId: user!.id,
      serviceId: service.id,
      status: paymentMode === 'ONLINE' ? 'SUBMITTED' : 'DRAFT',
      formData,
      uploads: uploadedFiles,
      paymentMode,
      paymentStatus: paymentMode === 'ONLINE' ? 'PAID' : 'OFFLINE_PENDING',
      fulfillmentMethod,
      deliveryAddress: fulfillmentMethod === 'HOME_DELIVERY' ? deliveryAddress : undefined,
      totalAmount: calculateTotal(),
      platformFee: Math.round(calculateTotal() * 0.2),
      consentGiven
    });
    
    setSubmittedRequestId(request.id);
    setProcessing(false);
    setShowPaymentModal(false);
    setSubmitted(true);
  };
  
  const renderField = (field: FormField) => {
    const value = formData[field.key] || '';
    
    switch (field.type) {
      case 'select':
        return (
          <Select
            key={field.key}
            label={field.label}
            name={field.key}
            value={value}
            onChange={(e) => handleFieldChange(field.key, e.target.value)}
            options={field.options || []}
            required={field.required}
            error={errors[field.key]}
          />
        );
      case 'textarea':
        return (
          <Textarea
            key={field.key}
            label={field.label}
            name={field.key}
            value={value}
            onChange={(e) => handleFieldChange(field.key, e.target.value)}
            placeholder={field.placeholder}
            required={field.required}
            error={errors[field.key]}
          />
        );
      default:
        return (
          <Input
            key={field.key}
            label={field.label}
            type={field.type}
            name={field.key}
            value={value}
            onChange={(e) => handleFieldChange(field.key, e.target.value)}
            placeholder={field.placeholder}
            required={field.required}
            error={errors[field.key]}
          />
        );
    }
  };
  
  const renderUploadField = (upload: UploadField) => {
    const file = uploads[upload.tag];
    
    return (
      <div key={upload.tag} className="border-2 border-dashed border-gray-200 rounded-xl p-6 hover:border-saffron transition-colors">
        <div className="flex items-start justify-between">
          <div>
            <p className="font-medium text-navy">{upload.label}</p>
            {upload.labelHi && (
              <p className="text-sm text-gray-500 hindi-text">{upload.labelHi}</p>
            )}
            {upload.required && (
              <span className="text-xs text-red-500">*Required</span>
            )}
          </div>
          
          {file ? (
            <div className="flex items-center gap-2">
              <span className="text-sm text-green-600 flex items-center gap-1">
                <CheckCircle className="w-4 h-4" />
                {file.name.slice(0, 20)}...
              </span>
              <button
                type="button"
                onClick={() => handleFileChange(upload.tag, null)}
                className="p-1 text-red-500 hover:bg-red-50 rounded"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <label className="cursor-pointer">
              <input
                type="file"
                className="hidden"
                accept={upload.acceptedTypes?.join(',')}
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) handleFileChange(upload.tag, file);
                }}
              />
              <span className="flex items-center gap-2 px-4 py-2 bg-saffron/10 text-saffron rounded-lg hover:bg-saffron/20 transition-colors">
                <Upload className="w-4 h-4" />
                Upload
              </span>
            </label>
          )}
        </div>
        {errors[upload.tag] && (
          <p className="text-sm text-red-600 mt-2">{errors[upload.tag]}</p>
        )}
      </div>
    );
  };
  
  if (submitted) {
    return (
      <div className="min-h-screen bg-bg py-12 animate-fade-in">
        <div className="max-w-2xl mx-auto px-4">
          <Card className="text-center p-8">
            <div className="w-20 h-20 bg-green/10 rounded-full flex items-center justify-center mx-auto mb-6">
              <CheckCircle className="w-10 h-10 text-green" />
            </div>
            <h2 className="text-2xl font-bold text-navy mb-2">Application Submitted!</h2>
            <p className="text-gray-600 mb-6">
              Your request has been submitted successfully. You can track the status using your request ID.
            </p>
            
            <div className="bg-gray-50 rounded-xl p-4 mb-6">
              <p className="text-sm text-gray-500 mb-1">Request ID</p>
              <p className="text-xl font-mono font-bold text-navy">{submittedRequestId}</p>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button onClick={() => navigate(`/request/${submittedRequestId}`)}>
                View Request Details
              </Button>
              <Button variant="outline" onClick={() => navigate('/services')}>
                Apply for Another Service
              </Button>
            </div>
          </Card>
        </div>
      </div>
    );
  }
  
  return (
    <div className="min-h-screen bg-bg py-8 animate-fade-in">
      <div className="max-w-3xl mx-auto px-4">
        {/* Header */}
        <div className="mb-8">
          <button
            onClick={() => navigate(-1)}
            className="flex items-center gap-2 text-gray-600 hover:text-navy mb-4"
          >
            <ArrowLeft className="w-4 h-4" />
            Back
          </button>
          
          <h1 className="text-2xl font-bold text-navy mb-1">{service.name}</h1>
          <p className="text-gray-600 hindi-text">{service.nameHi}</p>
        </div>
        
        {/* Progress Steps */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            {[...schema.steps.map(s => s.title), 'Delivery', 'Review & Pay'].map((_, idx) => (
              <div key={idx} className="flex-1 flex items-center">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium shrink-0 ${
                  idx < currentStep 
                    ? 'bg-green text-white' 
                    : idx === currentStep 
                    ? 'bg-saffron text-white' 
                    : 'bg-gray-200 text-gray-500'
                }`}>
                  {idx < currentStep ? <Check className="w-4 h-4" /> : idx + 1}
                </div>
                {idx < totalSteps - 1 && (
                  <div className={`flex-1 h-1 mx-2 ${
                    idx < currentStep ? 'bg-green' : 'bg-gray-200'
                  }`} />
                )}
              </div>
            ))}
          </div>
          <div className="flex justify-between mt-2">
            {[...schema.steps.map(s => s.title), 'Delivery', 'Review'].map((step, idx) => (
              <span 
                key={idx} 
                className={`text-xs text-center flex-1 ${
                  idx === currentStep ? 'text-saffron font-medium' : 'text-gray-500'
                }`}
              >
                {step}
              </span>
            ))}
          </div>
        </div>
        
        <Card>
          {/* Form Steps */}
          {currentStep < schema.steps.length && (
            <div className="animate-fade-in">
              <h2 className="text-xl font-semibold text-navy mb-6">
                {schema.steps[currentStep].title}
                {schema.steps[currentStep].titleHi && (
                  <span className="text-gray-500 text-base font-normal ml-2 hindi-text">
                    ({schema.steps[currentStep].titleHi})
                  </span>
                )}
              </h2>
              
              {schema.steps[currentStep].fields && (
                <div className="grid gap-4 md:grid-cols-2">
                  {schema.steps[currentStep].fields.map(field => (
                    <div key={field.key} className={field.type === 'textarea' ? 'md:col-span-2' : ''}>
                      {renderField(field)}
                    </div>
                  ))}
                </div>
              )}
              
              {schema.steps[currentStep].uploads && (
                <div className="space-y-4">
                  {schema.steps[currentStep].uploads.map(upload => renderUploadField(upload))}
                </div>
              )}
            </div>
          )}
          
          {/* Fulfillment Step */}
          {currentStep === schema.steps.length && (
            <div className="animate-fade-in">
              <h2 className="text-xl font-semibold text-navy mb-6">Delivery Options</h2>
              
              <div className="space-y-4 mb-6">
                <label 
                  className={`flex items-start gap-4 p-4 border-2 rounded-xl cursor-pointer transition-all ${
                    fulfillmentMethod === 'DIGITAL_ONLY' 
                      ? 'border-saffron bg-saffron/5' 
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <input
                    type="radio"
                    name="fulfillment"
                    checked={fulfillmentMethod === 'DIGITAL_ONLY'}
                    onChange={() => setFulfillmentMethod('DIGITAL_ONLY')}
                    className="mt-1"
                  />
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <Monitor className="w-5 h-5 text-saffron" />
                      <span className="font-medium text-navy">Digital Only</span>
                    </div>
                    <p className="text-sm text-gray-500 mt-1">
                      Receive documents digitally via email/WhatsApp
                    </p>
                    <span className="text-green font-medium text-sm">Free</span>
                  </div>
                </label>
                
                <label 
                  className={`flex items-start gap-4 p-4 border-2 rounded-xl cursor-pointer transition-all ${
                    fulfillmentMethod === 'PARTNER_PICKUP' 
                      ? 'border-saffron bg-saffron/5' 
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <input
                    type="radio"
                    name="fulfillment"
                    checked={fulfillmentMethod === 'PARTNER_PICKUP'}
                    onChange={() => setFulfillmentMethod('PARTNER_PICKUP')}
                    className="mt-1"
                  />
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <Store className="w-5 h-5 text-saffron" />
                      <span className="font-medium text-navy">Pickup from Partner</span>
                    </div>
                    <p className="text-sm text-gray-500 mt-1">
                      Collect your documents from nearest partner center
                    </p>
                    <span className="text-green font-medium text-sm">Free</span>
                  </div>
                </label>
                
                <label 
                  className={`flex items-start gap-4 p-4 border-2 rounded-xl cursor-pointer transition-all ${
                    fulfillmentMethod === 'HOME_DELIVERY' 
                      ? 'border-saffron bg-saffron/5' 
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <input
                    type="radio"
                    name="fulfillment"
                    checked={fulfillmentMethod === 'HOME_DELIVERY'}
                    onChange={() => setFulfillmentMethod('HOME_DELIVERY')}
                    className="mt-1"
                  />
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <Truck className="w-5 h-5 text-saffron" />
                      <span className="font-medium text-navy">Home Delivery</span>
                    </div>
                    <p className="text-sm text-gray-500 mt-1">
                      Get documents delivered to your doorstep
                    </p>
                    <span className="text-saffron font-medium text-sm">+₹{service.deliveryFee}</span>
                  </div>
                </label>
              </div>
              
              {fulfillmentMethod === 'HOME_DELIVERY' && (
                <div className="border-t border-gray-100 pt-6 animate-fade-in">
                  <h3 className="font-medium text-navy mb-4 flex items-center gap-2">
                    <MapPin className="w-5 h-5 text-saffron" />
                    Delivery Address
                  </h3>
                  <div className="grid gap-4 md:grid-cols-2">
                    <Input
                      label="Recipient Name"
                      value={deliveryAddress.name}
                      onChange={(e) => setDeliveryAddress(prev => ({ ...prev, name: e.target.value }))}
                      required
                    />
                    <Input
                      label="Mobile Number"
                      type="tel"
                      value={deliveryAddress.mobile}
                      onChange={(e) => setDeliveryAddress(prev => ({ ...prev, mobile: e.target.value }))}
                      required
                    />
                    <div className="md:col-span-2">
                      <Input
                        label="Address Line 1"
                        value={deliveryAddress.addressLine1}
                        onChange={(e) => setDeliveryAddress(prev => ({ ...prev, addressLine1: e.target.value }))}
                        required
                      />
                    </div>
                    <Input
                      label="City/Village"
                      value={deliveryAddress.city}
                      onChange={(e) => setDeliveryAddress(prev => ({ ...prev, city: e.target.value }))}
                      required
                    />
                    <Input
                      label="Pincode"
                      value={deliveryAddress.pincode}
                      onChange={(e) => setDeliveryAddress(prev => ({ ...prev, pincode: e.target.value }))}
                      required
                    />
                  </div>
                </div>
              )}
            </div>
          )}
          
          {/* Review Step */}
          {currentStep === schema.steps.length + 1 && (
            <div className="animate-fade-in">
              <h2 className="text-xl font-semibold text-navy mb-6">Review & Submit</h2>
              
              {/* Service Summary */}
              <div className="bg-gray-50 rounded-xl p-4 mb-6">
                <h3 className="font-medium text-navy mb-3">Service Details</h3>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">{service.name}</span>
                  <span className="font-medium">₹{service.price}</span>
                </div>
                {fulfillmentMethod === 'HOME_DELIVERY' && (
                  <div className="flex justify-between text-sm mt-2">
                    <span className="text-gray-600">Home Delivery</span>
                    <span className="font-medium">₹{service.deliveryFee}</span>
                  </div>
                )}
                <div className="border-t border-gray-200 mt-3 pt-3 flex justify-between">
                  <span className="font-semibold text-navy">Total</span>
                  <span className="font-bold text-xl text-saffron">₹{calculateTotal()}</span>
                </div>
              </div>
              
              {/* Form Data Summary */}
              <div className="mb-6">
                <h3 className="font-medium text-navy mb-3">Application Details</h3>
                <div className="grid gap-2 text-sm">
                  {Object.entries(formData).map(([key, value]) => (
                    <div key={key} className="flex justify-between py-2 border-b border-gray-100">
                      <span className="text-gray-600 capitalize">{key.replace(/_/g, ' ')}</span>
                      <span className="font-medium text-navy">{value}</span>
                    </div>
                  ))}
                </div>
              </div>
              
              {/* Documents */}
              <div className="mb-6">
                <h3 className="font-medium text-navy mb-3">Uploaded Documents</h3>
                <div className="flex flex-wrap gap-2">
                  {Object.entries(uploads).map(([tag]) => (
                    <span key={tag} className="px-3 py-1 bg-green/10 text-green text-sm rounded-full flex items-center gap-1">
                      <CheckCircle className="w-4 h-4" />
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
              
              {/* Payment Mode */}
              <div className="mb-6">
                <h3 className="font-medium text-navy mb-3">Payment Method</h3>
                <div className="grid gap-3 md:grid-cols-2">
                  <label 
                    className={`flex items-center gap-3 p-4 border-2 rounded-xl cursor-pointer transition-all ${
                      paymentMode === 'ONLINE' 
                        ? 'border-saffron bg-saffron/5' 
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <input
                      type="radio"
                      name="payment"
                      checked={paymentMode === 'ONLINE'}
                      onChange={() => setPaymentMode('ONLINE')}
                    />
                    <CreditCard className="w-5 h-5 text-saffron" />
                    <span className="font-medium text-navy">Pay Online</span>
                  </label>
                  
                  <label 
                    className={`flex items-center gap-3 p-4 border-2 rounded-xl cursor-pointer transition-all ${
                      paymentMode === 'OFFLINE_AT_PARTNER' 
                        ? 'border-saffron bg-saffron/5' 
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <input
                      type="radio"
                      name="payment"
                      checked={paymentMode === 'OFFLINE_AT_PARTNER'}
                      onChange={() => setPaymentMode('OFFLINE_AT_PARTNER')}
                    />
                    <Store className="w-5 h-5 text-saffron" />
                    <span className="font-medium text-navy">Pay at Partner</span>
                  </label>
                </div>
              </div>
              
              {/* Consent */}
              <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-4 mb-6">
                <label className="flex items-start gap-3 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={consentGiven}
                    onChange={(e) => setConsentGiven(e.target.checked)}
                    className="mt-1"
                  />
                  <div>
                    <p className="text-sm text-navy">{schema.consent.text}</p>
                    {schema.consent.textHi && (
                      <p className="text-sm text-gray-600 hindi-text mt-1">{schema.consent.textHi}</p>
                    )}
                  </div>
                </label>
                {errors.consent && (
                  <p className="text-sm text-red-600 mt-2">{errors.consent}</p>
                )}
              </div>
            </div>
          )}
          
          {/* Navigation Buttons */}
          <div className="flex justify-between mt-8 pt-6 border-t border-gray-100">
            <Button
              variant="ghost"
              onClick={handlePrev}
              disabled={currentStep === 0}
              icon={<ArrowLeft className="w-4 h-4" />}
            >
              Previous
            </Button>
            
            {currentStep < totalSteps - 1 ? (
              <Button
                onClick={handleNext}
                icon={<ArrowRight className="w-4 h-4" />}
              >
                Next
              </Button>
            ) : (
              <Button
                onClick={handleSubmit}
                variant="secondary"
              >
                {isAuthenticated ? `Pay ₹${calculateTotal()}` : 'Login & Pay'}
              </Button>
            )}
          </div>
        </Card>
      </div>
      
      {/* Payment Modal */}
      <Modal
        isOpen={showPaymentModal}
        onClose={() => !processing && setShowPaymentModal(false)}
        title="Complete Payment"
        size="sm"
      >
        <div className="text-center">
          <div className="w-16 h-16 bg-saffron/10 rounded-full flex items-center justify-center mx-auto mb-4">
            <CreditCard className="w-8 h-8 text-saffron" />
          </div>
          
          <h3 className="text-xl font-bold text-navy mb-2">₹{calculateTotal()}</h3>
          <p className="text-gray-600 mb-6">
            {paymentMode === 'ONLINE' 
              ? 'Complete payment via Razorpay' 
              : 'Pay at partner center when collecting documents'}
          </p>
          
          <Button
            className="w-full"
            onClick={processPayment}
            loading={processing}
          >
            {paymentMode === 'ONLINE' ? 'Pay Now (Demo)' : 'Confirm Request'}
          </Button>
          
          <p className="text-xs text-gray-500 mt-4">
            This is a demo payment. No actual charges will be made.
          </p>
        </div>
      </Modal>
    </div>
  );
};
