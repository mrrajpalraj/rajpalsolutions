import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { 
  ArrowRight, 
  CreditCard, 
  FileCheck, 
  MapPin, 
  Shield, 
  Clock, 
  Users,
  Star,
  Phone,
  CheckCircle,
  Truck,
  Car,
  FileText,
  Heart,
  Scale,
  HelpCircle,
  Globe,
  Smartphone
} from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { serviceCategories, services } from '@/data/services';

const iconMap: Record<string, React.ReactNode> = {
  CreditCard: <CreditCard className="w-6 h-6" />,
  Fingerprint: <Shield className="w-6 h-6" />,
  Vote: <FileCheck className="w-6 h-6" />,
  Car: <Car className="w-6 h-6" />,
  Truck: <Truck className="w-6 h-6" />,
  MapPin: <MapPin className="w-6 h-6" />,
  FileCheck: <FileCheck className="w-6 h-6" />,
  Heart: <Heart className="w-6 h-6" />,
  FileText: <FileText className="w-6 h-6" />
};

const stats = [
  { number: '10,000+', label: 'Happy Citizens', labelHindi: 'खुश नागरिक', color: 'saffron' },
  { number: '50+', label: 'Services', labelHindi: 'सेवाएं', color: 'green' },
  { number: '7', label: 'Block Coverage', labelHindi: 'ब्लॉक कवरेज', color: 'navy' },
  { number: '24/7', label: 'Support', labelHindi: 'सहायता', color: 'saffron' },
];

const blocks = ['Damoh', 'Pathariya', 'Patera', 'Batiyagarh', 'Tendukheda', 'Hatta', 'Jabera'];

export const HomePage: React.FC = () => {
  const navigate = useNavigate();
  const featuredServices = services.slice(0, 6);
  
  return (
    <div className="animate-fade-in">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-navy via-navy-light to-navy text-white overflow-hidden">
        {/* Animated Background */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-20 right-10 w-72 h-72 bg-saffron/20 rounded-full blur-3xl animate-float"></div>
          <div className="absolute bottom-20 left-10 w-96 h-96 bg-green/15 rounded-full blur-3xl animate-float-slow"></div>
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] border border-white/5 rounded-full animate-rotate-slow"></div>
        </div>
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-24">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="animate-slide-up">
              {/* Badge */}
              <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/10 backdrop-blur-sm rounded-full text-sm mb-6 border border-white/20">
                <span className="w-2 h-2 bg-green rounded-full animate-pulse"></span>
                <span className="text-white/90">देश और दुनिया डिजिटल हो रहे हैं, तो हम पीछे क्यों रहें</span>
              </div>
              
              {/* Main Heading */}
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 leading-tight">
                <span className="text-saffron font-hindi">राजपाल सोल्यूशंस</span>
                <br />
                <span className="text-white">आपका स्वागत करता है</span>
              </h1>
              
              {/* Tagline */}
              <p className="text-xl md:text-2xl text-white font-hindi mb-4 leading-relaxed">
                "आप हम तक पहुँचिए, हम समाधान तक पहुँचा देंगे"
              </p>
              
              {/* Slogan */}
              <p className="text-lg text-saffron-light font-semibold mb-8 font-hindi">
                "अब आप निश्चिंत रहिये, हम चिंता करेंगे"
              </p>
              
              <p className="text-gray-300 mb-10 max-w-xl text-lg leading-relaxed">
                PAN Card, Aadhaar, Driving License, Land Records, Certificates और 50+ सरकारी सेवाओं के लिए आपका विश्वसनीय साथी। दमोह जिले के सभी 7 ब्लॉक में सेवा उपलब्ध।
              </p>
              
              {/* CTA Buttons */}
              <div className="flex flex-col sm:flex-row gap-4">
                <Button 
                  size="lg" 
                  onClick={() => navigate('/services')}
                  className="text-lg"
                >
                  सेवाएं देखें
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
                <Button 
                  variant="outline" 
                  size="lg"
                  onClick={() => navigate('/contact')}
                  className="border-2 border-white text-white hover:bg-white hover:text-navy text-lg"
                >
                  <Phone className="w-5 h-5 mr-2" />
                  संपर्क करें
                </Button>
              </div>
              
              {/* Trust Badges */}
              <div className="flex flex-wrap items-center gap-6 mt-10">
                <div className="flex items-center gap-2 text-white/80">
                  <Shield className="w-5 h-5 text-green" />
                  <span className="text-sm font-medium">100% Secure</span>
                </div>
                <div className="flex items-center gap-2 text-white/80">
                  <Clock className="w-5 h-5 text-saffron" />
                  <span className="text-sm font-medium">Fast Processing</span>
                </div>
                <div className="flex items-center gap-2 text-white/80">
                  <Star className="w-5 h-5 text-yellow-400" />
                  <span className="text-sm font-medium">4.9 Rating</span>
                </div>
              </div>
            </div>
            
            {/* Hero Card */}
            <div className="hidden lg:block relative animate-slide-in-right">
              <div className="relative">
                <Card className="bg-white/95 backdrop-blur-lg p-8 shadow-2xl">
                  <div className="text-center mb-6">
                    <div className="w-20 h-20 mx-auto bg-gradient-to-br from-saffron to-saffron-dark rounded-2xl flex items-center justify-center mb-4 shadow-lg animate-pulse-glow">
                      <FileText className="w-10 h-10 text-white" />
                    </div>
                    <h3 className="text-xl font-bold text-navy">Quick Service Request</h3>
                    <p className="text-gray-500 font-hindi">तुरंत सेवा अनुरोध</p>
                  </div>
                  
                  <div className="space-y-4">
                    <div className="flex items-center gap-3 p-4 bg-green/10 rounded-xl border border-green/20">
                      <CheckCircle className="w-6 h-6 text-green" />
                      <span className="font-medium text-navy">Select Your Service</span>
                    </div>
                    <div className="flex items-center gap-3 p-4 bg-saffron/10 rounded-xl border border-saffron/20">
                      <FileText className="w-6 h-6 text-saffron" />
                      <span className="font-medium text-navy">Upload Documents</span>
                    </div>
                    <div className="flex items-center gap-3 p-4 bg-blue-50 rounded-xl border border-blue-100">
                      <CreditCard className="w-6 h-6 text-blue-500" />
                      <span className="font-medium text-navy">Pay & Track Status</span>
                    </div>
                    
                    <Button className="w-full mt-4" onClick={() => navigate('/services')}>
                      Get Started
                    </Button>
                  </div>
                </Card>
                
                {/* Floating Badges */}
                <div className="absolute -top-4 -right-4 bg-green text-white px-4 py-2 rounded-full text-sm font-bold shadow-lg animate-bounce">
                  50+ Services
                </div>
                <div className="absolute -bottom-4 -left-4 bg-saffron text-white px-4 py-2 rounded-full text-sm font-bold shadow-lg animate-bounce delay-300">
                  7 Blocks
                </div>
              </div>
            </div>
          </div>
        </div>
        
        {/* Wave Divider */}
        <div className="absolute bottom-0 left-0 right-0">
          <svg viewBox="0 0 1440 120" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M0 120L60 110C120 100 240 80 360 70C480 60 600 60 720 65C840 70 960 80 1080 85C1200 90 1320 90 1380 90L1440 90V120H1380C1320 120 1200 120 1080 120C960 120 840 120 720 120C600 120 480 120 360 120C240 120 120 120 60 120H0Z" fill="#F8FAFC"/>
          </svg>
        </div>
      </section>
      
      {/* Stats Section */}
      <section className="py-16 bg-white relative z-10 -mt-1">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
            {stats.map((stat, index) => (
              <div 
                key={index}
                className="text-center p-6 rounded-2xl bg-gradient-to-br from-white to-gray-50 shadow-lg border border-gray-100 card-hover animate-scale-in"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <div className={`text-4xl md:text-5xl font-bold mb-2 ${
                  stat.color === 'saffron' ? 'text-saffron' : 
                  stat.color === 'green' ? 'text-green' : 'text-navy'
                }`}>
                  {stat.number}
                </div>
                <p className="text-gray-700 font-semibold">{stat.label}</p>
                <p className="text-sm text-gray-500 font-hindi">{stat.labelHindi}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
      
      {/* Problem Section */}
      <section className="py-20 bg-gradient-to-br from-navy via-navy-light to-navy text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              <span className="font-hindi">चलिए एक बार समस्या की ओर नज़र डालते हैं...</span>
            </h2>
            <p className="text-xl text-gray-300 font-hindi max-w-3xl mx-auto">
              भ्रष्टाचार की वजह से समस्याएं और भी जटिल हो जाती हैं। अधिकारी सुनते नहीं हैं, और आम आदमी की समस्याएं समस्या ही बनी रहती हैं।
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <Card className="bg-white/10 backdrop-blur-sm border border-white/10 p-8 card-hover">
              <div className="w-14 h-14 bg-saffron/20 rounded-xl flex items-center justify-center mb-4">
                <Scale className="w-7 h-7 text-saffron" />
              </div>
              <h3 className="text-xl font-bold mb-3 text-white">जटिल प्रक्रियाएं</h3>
              <p className="text-gray-300 font-hindi">
                सरकारी दफ्तरों में लंबी लाइनें, जटिल फॉर्म और अनगिनत चक्कर। हम इसे आसान बनाते हैं।
              </p>
            </Card>

            <Card className="bg-white/10 backdrop-blur-sm border border-white/10 p-8 card-hover">
              <div className="w-14 h-14 bg-green/20 rounded-xl flex items-center justify-center mb-4">
                <Clock className="w-7 h-7 text-green" />
              </div>
              <h3 className="text-xl font-bold mb-3 text-white">समय की बर्बादी</h3>
              <p className="text-gray-300 font-hindi">
                दिन भर का समय खराब, फिर भी काम अधूरा। हमारे साथ घर बैठे काम पूरा।
              </p>
            </Card>

            <Card className="bg-white/10 backdrop-blur-sm border border-white/10 p-8 card-hover">
              <div className="w-14 h-14 bg-red-500/20 rounded-xl flex items-center justify-center mb-4">
                <HelpCircle className="w-7 h-7 text-red-400" />
              </div>
              <h3 className="text-xl font-bold mb-3 text-white">सही मार्गदर्शन की कमी</h3>
              <p className="text-gray-300 font-hindi">
                कौन सा फॉर्म? कौन सा दस्तावेज? हम सब बताएंगे और करके देंगे।
              </p>
            </Card>
          </div>

          <div className="text-center mt-12">
            <p className="text-2xl font-bold text-saffron mb-2 font-hindi">
              "हमारे पास समस्या का समाधान है"
            </p>
            <p className="text-gray-300 font-hindi text-lg">
              आपकी समस्या हमारी समस्या। आप हमसे जुड़िए, हम समाधान से जोड़ देंगे।
            </p>
          </div>
        </div>
      </section>
      
      {/* Features Strip */}
      <section className="py-12 bg-white border-y border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            {[
              { icon: Shield, title: 'Secure & Trusted', titleHi: 'सुरक्षित और विश्वसनीय', desc: 'Your data is encrypted and safe' },
              { icon: Clock, title: 'Fast Processing', titleHi: 'तेज़ प्रोसेसिंग', desc: 'Quick turnaround times' },
              { icon: Truck, title: 'Home Delivery', titleHi: 'होम डिलीवरी', desc: 'Documents at your doorstep' },
              { icon: Users, title: 'Expert Support', titleHi: 'विशेषज्ञ सहायता', desc: 'Trained professionals help you' }
            ].map((feature, idx) => (
              <div 
                key={idx} 
                className="text-center p-6 rounded-2xl hover:bg-gray-50 transition-all duration-300 group"
              >
                <div className={`w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4 transition-all duration-300 group-hover:scale-110 ${
                  idx % 2 === 0 ? 'bg-saffron/10 text-saffron' : 'bg-green/10 text-green'
                }`}>
                  <feature.icon className="w-8 h-8" />
                </div>
                <h3 className="font-bold text-navy mb-1">{feature.title}</h3>
                <p className="text-sm text-gray-500 font-hindi mb-1">{feature.titleHi}</p>
                <p className="text-gray-500 text-sm">{feature.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
      
      {/* Service Categories */}
      <section className="py-20 bg-bg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <span className="inline-block px-4 py-2 bg-saffron/10 text-saffron rounded-full text-sm font-semibold mb-4">
              हमारी सेवाएं
            </span>
            <h2 className="text-3xl md:text-4xl font-bold text-navy mb-4">
              Our Service Categories
            </h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              We provide comprehensive government service assistance across multiple categories
            </p>
          </div>
          
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {serviceCategories.map((category, idx) => (
              <Card 
                key={category.id} 
                hover 
                className="group cursor-pointer"
                onClick={() => navigate(`/services?category=${category.id}`)}
              >
                <div className="flex items-start gap-4">
                  <div className={`w-14 h-14 rounded-xl flex items-center justify-center text-white shrink-0 group-hover:scale-110 transition-transform duration-300 ${
                    idx % 2 === 0 ? 'bg-gradient-to-br from-saffron to-saffron-dark' : 'bg-gradient-to-br from-green to-green-dark'
                  }`}>
                    {iconMap[category.icon]}
                  </div>
                  <div className="flex-1">
                    <h3 className="font-bold text-navy group-hover:text-saffron transition-colors">
                      {category.name}
                    </h3>
                    <p className="text-gray-500 text-sm font-hindi">{category.nameHi}</p>
                    <p className="text-gray-400 text-sm mt-1">{category.description}</p>
                  </div>
                  <ArrowRight className="w-5 h-5 text-gray-400 group-hover:text-saffron group-hover:translate-x-1 transition-all" />
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>
      
      {/* Popular Services */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-12">
            <div>
              <span className="inline-block px-4 py-2 bg-green/10 text-green rounded-full text-sm font-semibold mb-4">
                लोकप्रिय सेवाएं
              </span>
              <h2 className="text-3xl md:text-4xl font-bold text-navy mb-2">Popular Services</h2>
              <p className="text-gray-600">Most requested services by our customers</p>
            </div>
            <Link 
              to="/services" 
              className="hidden md:flex items-center gap-2 text-saffron font-semibold hover:underline"
            >
              View All <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
          
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {featuredServices.map((service, idx) => (
              <Card key={service.id} hover className="group">
                <div className="mb-4">
                  <span className={`inline-block px-3 py-1 text-xs font-semibold rounded-full ${
                    idx % 2 === 0 ? 'bg-saffron/10 text-saffron' : 'bg-green/10 text-green'
                  }`}>
                    {serviceCategories.find(c => c.id === service.categoryId)?.name}
                  </span>
                </div>
                <h3 className="text-lg font-bold text-navy mb-1 group-hover:text-saffron transition-colors">
                  {service.name}
                </h3>
                <p className="text-gray-500 text-sm font-hindi mb-3">{service.nameHi}</p>
                <p className="text-gray-600 text-sm mb-4">{service.description}</p>
                
                <div className="flex items-center justify-between pt-4 border-t border-gray-100">
                  <div>
                    <span className="text-2xl font-bold text-navy">₹{service.price}</span>
                    {service.deliveryFee > 0 && (
                      <span className="text-gray-400 text-sm ml-2">
                        +₹{service.deliveryFee} delivery
                      </span>
                    )}
                  </div>
                  <Button 
                    size="sm"
                    onClick={() => navigate(`/apply/${service.id}`)}
                  >
                    Apply Now
                  </Button>
                </div>
                
                <div className="flex items-center gap-2 mt-4 text-sm text-gray-500">
                  <Clock className="w-4 h-4" />
                  <span>{service.processingTime}</span>
                </div>
              </Card>
            ))}
          </div>
          
          <div className="text-center mt-8 md:hidden">
            <Link 
              to="/services" 
              className="inline-flex items-center gap-2 text-saffron font-semibold"
            >
              View All Services <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </section>
      
      {/* How It Works */}
      <section className="py-20 bg-bg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <span className="inline-block px-4 py-2 bg-saffron/10 text-saffron rounded-full text-sm font-semibold mb-4">
              How It Works
            </span>
            <h2 className="text-3xl md:text-4xl font-bold text-navy mb-4">
              <span className="font-hindi">4 आसान स्टेप्स में काम पूरा</span>
            </h2>
            <p className="text-gray-600">Simple 4-step process to get your government services done</p>
          </div>
          
          <div className="grid md:grid-cols-4 gap-8">
            {[
              { step: 1, title: 'Choose Service', titleHi: 'सेवा चुनें', desc: 'Browse our 50+ services and select what you need', icon: <Globe className="w-8 h-8" /> },
              { step: 2, title: 'Fill Details', titleHi: 'विवरण भरें', desc: 'Complete the easy form with required details', icon: <FileText className="w-8 h-8" /> },
              { step: 3, title: 'Pay Securely', titleHi: 'भुगतान करें', desc: 'Pay online or at partner location', icon: <CreditCard className="w-8 h-8" /> },
              { step: 4, title: 'Track & Receive', titleHi: 'ट्रैक करें', desc: 'Track status and receive at home or pickup', icon: <Truck className="w-8 h-8" /> },
            ].map((item, idx) => (
              <div key={idx} className="relative text-center">
                {idx < 3 && (
                  <div className="hidden md:block absolute top-12 left-[60%] w-[80%] h-1 bg-gradient-to-r from-saffron to-green z-0"></div>
                )}
                
                <div className="relative z-10 animate-slide-up" style={{ animationDelay: `${idx * 0.15}s` }}>
                  <div className={`w-24 h-24 mx-auto rounded-2xl flex items-center justify-center mb-4 shadow-lg text-white ${
                    idx % 2 === 0 ? 'bg-gradient-to-br from-saffron to-saffron-dark' : 'bg-gradient-to-br from-green to-green-dark'
                  }`}>
                    {item.icon}
                  </div>
                  <div className="absolute -top-2 -right-2 w-8 h-8 bg-navy text-white rounded-full flex items-center justify-center font-bold text-sm shadow-lg">
                    {item.step}
                  </div>
                  <h3 className="text-xl font-bold text-navy mb-1">{item.title}</h3>
                  <p className="text-sm text-gray-500 font-hindi mb-2">{item.titleHi}</p>
                  <p className="text-gray-600 text-sm">{item.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
      
      {/* Partner Section */}
      <section className="py-20 bg-gradient-to-br from-green to-green-dark text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <span className="inline-block px-4 py-2 bg-white/20 rounded-full text-sm font-semibold mb-4">
                Partner With Us
              </span>
              <h2 className="text-3xl md:text-4xl font-bold mb-4">
                <span className="font-hindi">हमारे साथ जुड़ें और कमाएं</span>
              </h2>
              <p className="text-green-100 text-lg mb-6 font-hindi">
                क्या आप MP Online, CSC Centre, Cyber Cafe या Photocopy की दुकान चलाते हैं? 
                हमारे साथ पार्टनर बनें और अपनी आय बढ़ाएं।
              </p>

              <div className="space-y-4 mb-8">
                {[
                  { title: 'Zero Investment', desc: 'कोई अग्रिम निवेश नहीं, बस हमारे साथ जुड़ें' },
                  { title: 'Earn Per Service', desc: 'हर सेवा पर कमीशन कमाएं' },
                  { title: 'Training & Support', desc: 'पूरा प्रशिक्षण और 24/7 सहायता' },
                ].map((item, idx) => (
                  <div key={idx} className="flex items-start gap-4">
                    <div className="w-10 h-10 bg-saffron/20 rounded-lg flex items-center justify-center flex-shrink-0">
                      <CheckCircle className="w-5 h-5 text-saffron" />
                    </div>
                    <div>
                      <h4 className="font-bold text-white">{item.title}</h4>
                      <p className="text-green-100 text-sm font-hindi">{item.desc}</p>
                    </div>
                  </div>
                ))}
              </div>

              <Button 
                onClick={() => navigate('/partner-register')}
                className="bg-saffron hover:bg-saffron-dark text-white"
              >
                Become a Partner
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </div>

            <div className="relative">
              <div className="bg-white/10 backdrop-blur-sm rounded-3xl p-8 border border-white/20">
                <h3 className="text-xl font-bold mb-6 text-center font-hindi">
                  दमोह जिले के 7 ब्लॉक में सेवा
                </h3>
                <div className="grid grid-cols-2 gap-4">
                  {blocks.map((block, index) => (
                    <div 
                      key={block}
                      className="bg-white rounded-xl p-4 text-center shadow-md card-hover animate-scale-in"
                      style={{ animationDelay: `${index * 0.1}s` }}
                    >
                      <MapPin className="w-6 h-6 text-saffron mx-auto mb-2" />
                      <span className="font-semibold text-navy">{block}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Floating card */}
              <div className="absolute -top-6 -right-6 bg-white rounded-2xl p-4 shadow-xl animate-float hidden lg:block">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-green rounded-full flex items-center justify-center">
                    <Users className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-navy">100+</p>
                    <p className="text-sm text-gray-500">Active Partners</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* Contact Section */}
      <section className="py-20 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <span className="inline-block px-4 py-2 bg-saffron/10 text-saffron rounded-full text-sm font-semibold mb-4">
            हमसे संपर्क करें
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-navy mb-4">Need Help?</h2>
          <p className="text-gray-600 mb-8 text-lg">
            Our team is here to assist you with any questions about our services
          </p>
          
          <div className="flex flex-col sm:flex-row items-center justify-center gap-6 mb-8">
            <a 
              href="tel:8269342506"
              className="flex items-center gap-4 px-8 py-5 bg-saffron/10 rounded-2xl hover:bg-saffron/20 transition-all duration-300 group"
            >
              <div className="w-14 h-14 bg-saffron rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                <Phone className="w-6 h-6 text-white" />
              </div>
              <div className="text-left">
                <p className="text-sm text-gray-500">Call us at</p>
                <p className="text-xl font-bold text-navy">8269342506</p>
              </div>
            </a>
            <a 
              href="tel:8085227600"
              className="flex items-center gap-4 px-8 py-5 bg-green/10 rounded-2xl hover:bg-green/20 transition-all duration-300 group"
            >
              <div className="w-14 h-14 bg-green rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                <Phone className="w-6 h-6 text-white" />
              </div>
              <div className="text-left">
                <p className="text-sm text-gray-500">Or call</p>
                <p className="text-xl font-bold text-navy">8085227600</p>
              </div>
            </a>
          </div>
          
          {/* WhatsApp Button */}
          <div className="mb-8">
            <a 
              href="https://wa.me/918269342506"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-3 px-8 py-4 bg-green text-white rounded-full font-semibold text-lg hover:bg-green-dark transition-colors shadow-lg hover:shadow-xl"
            >
              <Smartphone className="w-6 h-6" />
              WhatsApp पर जुड़ें
            </a>
          </div>
          
          <div className="flex items-center justify-center gap-2 text-gray-600">
            <MapPin className="w-5 h-5 text-saffron" />
            <span>
              District Collectorate, Maharana Pratap Chouraha, Jabalpur Naka, Damoh 470661
            </span>
          </div>
        </div>
      </section>
      
      {/* Tricolor stripe before footer */}
      <div className="h-2 bg-gradient-to-r from-saffron via-white to-green"></div>
    </div>
  );
};
