import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Phone, ArrowRight, Shield } from 'lucide-react';
import { Card } from '@/components/ui/Card';
import { Input } from '@/components/ui/Input';
import { Button } from '@/components/ui/Button';
import { useAuthStore } from '@/store';

export const LoginPage: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { login, verifyOtp, otpSent, pendingMobile } = useAuthStore();
  
  const [mobile, setMobile] = useState('');
  const [otp, setOtp] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  
  const from = (location.state as { from?: string })?.from || '/dashboard';
  
  const handleSendOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    if (!/^[6-9]\d{9}$/.test(mobile)) {
      setError('Please enter a valid 10-digit mobile number');
      return;
    }
    
    setLoading(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    login(mobile);
    setLoading(false);
  };
  
  const handleVerifyOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    if (otp.length !== 6) {
      setError('Please enter a 6-digit OTP');
      return;
    }
    
    setLoading(true);
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const success = verifyOtp(otp);
    if (success) {
      navigate(from, { replace: true });
    } else {
      setError('Invalid OTP. Try 123456');
    }
    setLoading(false);
  };
  
  return (
    <div className="min-h-[calc(100vh-180px)] flex items-center justify-center bg-bg py-12 px-4 animate-fade-in">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-gradient-to-br from-saffron to-saffron-dark rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg shadow-saffron/30">
            <span className="text-white font-bold text-2xl">R</span>
          </div>
          <h1 className="text-2xl font-bold text-navy mb-2">Welcome to Rajpal Solutions</h1>
          <p className="text-gray-600">Login with your mobile number</p>
        </div>
        
        <Card className="p-8">
          {!otpSent ? (
            <form onSubmit={handleSendOtp}>
              <div className="mb-6">
                <Input
                  label="Mobile Number"
                  type="tel"
                  placeholder="Enter 10-digit mobile number"
                  value={mobile}
                  onChange={(e) => setMobile(e.target.value.replace(/\D/g, '').slice(0, 10))}
                  icon={<Phone className="w-5 h-5" />}
                  error={error}
                  required
                />
              </div>
              
              <Button 
                type="submit" 
                className="w-full" 
                size="lg"
                loading={loading}
                icon={<ArrowRight className="w-5 h-5" />}
              >
                Get OTP
              </Button>
              
              <div className="mt-6 flex items-center justify-center gap-2 text-sm text-gray-500">
                <Shield className="w-4 h-4" />
                <span>Your data is secure with us</span>
              </div>
            </form>
          ) : (
            <form onSubmit={handleVerifyOtp}>
              <div className="text-center mb-6">
                <p className="text-gray-600 mb-1">OTP sent to</p>
                <p className="font-semibold text-navy text-lg">{pendingMobile}</p>
                <button
                  type="button"
                  onClick={() => {
                    useAuthStore.setState({ otpSent: false, pendingMobile: null });
                    setOtp('');
                    setError('');
                  }}
                  className="text-saffron text-sm hover:underline mt-2"
                >
                  Change number
                </button>
              </div>
              
              <div className="mb-6">
                <Input
                  label="Enter OTP"
                  type="text"
                  placeholder="Enter 6-digit OTP"
                  value={otp}
                  onChange={(e) => setOtp(e.target.value.replace(/\D/g, '').slice(0, 6))}
                  error={error}
                  className="text-center text-2xl tracking-widest font-mono"
                  required
                />
                <p className="text-sm text-gray-500 mt-2 text-center">
                  Demo OTP: <span className="font-mono font-semibold">123456</span>
                </p>
              </div>
              
              <Button 
                type="submit" 
                className="w-full" 
                size="lg"
                loading={loading}
              >
                Verify & Login
              </Button>
              
              <div className="mt-4 text-center">
                <button
                  type="button"
                  onClick={() => {
                    // Resend OTP logic
                    login(pendingMobile!);
                  }}
                  className="text-saffron text-sm hover:underline"
                >
                  Resend OTP
                </button>
              </div>
            </form>
          )}
        </Card>
        
        <p className="text-center text-sm text-gray-500 mt-6">
          By logging in, you agree to our{' '}
          <a href="/terms" className="text-saffron hover:underline">Terms</a> and{' '}
          <a href="/privacy" className="text-saffron hover:underline">Privacy Policy</a>
        </p>
      </div>
    </div>
  );
};
