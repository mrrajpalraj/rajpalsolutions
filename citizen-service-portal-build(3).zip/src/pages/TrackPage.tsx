import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, FileText, AlertCircle, ArrowRight } from 'lucide-react';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import { StatusBadge } from '@/components/ui/Badge';
import { useRequestStore } from '@/store';
import { services } from '@/data/services';

export const TrackPage: React.FC = () => {
  const navigate = useNavigate();
  const { getRequestById } = useRequestStore();
  
  const [requestId, setRequestId] = useState('');
  const [searchedRequest, setSearchedRequest] = useState<any>(null);
  const [notFound, setNotFound] = useState(false);
  const [searched, setSearched] = useState(false);
  
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setSearched(true);
    
    const request = getRequestById(requestId.trim());
    if (request) {
      setSearchedRequest(request);
      setNotFound(false);
    } else {
      setSearchedRequest(null);
      setNotFound(true);
    }
  };
  
  const service = searchedRequest ? services.find(s => s.id === searchedRequest.serviceId) : null;
  
  return (
    <div className="min-h-screen bg-bg py-12 animate-fade-in">
      <div className="max-w-2xl mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-saffron/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <Search className="w-8 h-8 text-saffron" />
          </div>
          <h1 className="text-3xl font-bold text-navy mb-2">Track Your Request</h1>
          <p className="text-gray-600">
            Enter your request ID to check the current status
          </p>
        </div>
        
        {/* Search Form */}
        <Card className="mb-8">
          <form onSubmit={handleSearch}>
            <div className="flex gap-4">
              <div className="flex-1">
                <Input
                  placeholder="Enter Request ID (e.g., abc123xyz)"
                  value={requestId}
                  onChange={(e) => setRequestId(e.target.value)}
                  icon={<FileText className="w-5 h-5" />}
                  className="text-lg"
                />
              </div>
              <Button type="submit" size="lg">
                Track
              </Button>
            </div>
          </form>
        </Card>
        
        {/* Results */}
        {searched && (
          <>
            {searchedRequest && service ? (
              <Card className="animate-slide-up">
                <div className="flex items-start justify-between mb-6">
                  <div>
                    <h3 className="text-xl font-semibold text-navy">{service.name}</h3>
                    <p className="text-gray-500 font-mono">ID: {searchedRequest.id}</p>
                  </div>
                  <StatusBadge status={searchedRequest.status} />
                </div>
                
                <div className="grid gap-4 mb-6">
                  <div className="flex justify-between py-2 border-b border-gray-100">
                    <span className="text-gray-600">Submitted On</span>
                    <span className="font-medium text-navy">
                      {new Date(searchedRequest.createdAt).toLocaleDateString()}
                    </span>
                  </div>
                  <div className="flex justify-between py-2 border-b border-gray-100">
                    <span className="text-gray-600">Payment Status</span>
                    <span className="font-medium text-navy capitalize">
                      {searchedRequest.paymentStatus.replace(/_/g, ' ').toLowerCase()}
                    </span>
                  </div>
                  <div className="flex justify-between py-2 border-b border-gray-100">
                    <span className="text-gray-600">Delivery Method</span>
                    <span className="font-medium text-navy capitalize">
                      {searchedRequest.fulfillmentMethod.replace(/_/g, ' ').toLowerCase()}
                    </span>
                  </div>
                  <div className="flex justify-between py-2">
                    <span className="text-gray-600">Total Amount</span>
                    <span className="font-bold text-saffron">₹{searchedRequest.totalAmount}</span>
                  </div>
                </div>
                
                <Button 
                  className="w-full"
                  onClick={() => navigate(`/request/${searchedRequest.id}`)}
                  icon={<ArrowRight className="w-4 h-4" />}
                >
                  View Full Details
                </Button>
              </Card>
            ) : notFound ? (
              <Card className="text-center animate-slide-up">
                <AlertCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-navy mb-2">Request Not Found</h3>
                <p className="text-gray-600 mb-6">
                  We couldn't find a request with ID: <span className="font-mono font-semibold">{requestId}</span>
                </p>
                <p className="text-sm text-gray-500">
                  Please check the request ID and try again, or contact support if you need help.
                </p>
              </Card>
            ) : null}
          </>
        )}
        
        {/* Help Section */}
        <div className="mt-8 text-center text-sm text-gray-500">
          <p>Can't find your request ID?</p>
          <p className="mt-1">
            Check your email or SMS for the confirmation message, or{' '}
            <a href="/contact" className="text-saffron hover:underline">contact support</a>.
          </p>
        </div>
      </div>
    </div>
  );
};
