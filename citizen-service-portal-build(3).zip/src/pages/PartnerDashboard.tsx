import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  FileText, 
  Wallet, 
  Users, 
  TrendingUp,
  CheckCircle,
  Clock,
  ArrowRight,
  Download,
  Phone,
  Plus,
  Minus
} from 'lucide-react';
import { Card, CardHeader } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { StatusBadge, VerificationBadge } from '@/components/ui/Badge';
import { Modal } from '@/components/ui/Modal';
import { Input } from '@/components/ui/Input';
import { useAuthStore, useRequestStore, usePartnerStore } from '@/store';
import { services } from '@/data/services';

export const PartnerDashboard: React.FC = () => {
  const navigate = useNavigate();
  const { user } = useAuthStore();
  const { requests, updateRequest } = useRequestStore();
  const { getPartnerByUserId, getWalletTransactions } = usePartnerStore();
  
  const partner = user ? getPartnerByUserId(user.id) : null;
  const walletTransactions = partner ? getWalletTransactions(partner.id) : [];
  
  const [selectedRequest, setSelectedRequest] = useState<any>(null);
  const [showOtpModal, setShowOtpModal] = useState(false);
  const [otp, setOtp] = useState('');
  
  // Mock: Get assigned requests for this partner
  const assignedRequests = requests.filter(r => r.partnerId === partner?.id);
  
  const pendingRequests = assignedRequests.filter(r => 
    ['ASSIGNED', 'PROCESSING'].includes(r.status)
  );
  const completedRequests = assignedRequests.filter(r => r.status === 'COMPLETED');
  
  const stats = {
    pending: pendingRequests.length,
    completed: completedRequests.length,
    walletBalance: partner?.walletBalance || 0,
    totalEarnings: walletTransactions
      .filter(t => t.type === 'CREDIT')
      .reduce((sum, t) => sum + t.amount, 0)
  };
  
  const handleAcceptRequest = (requestId: string) => {
    if (!user) return;
    updateRequest(requestId, { status: 'PROCESSING' }, user.id, 'PARTNER', 'Request accepted by partner');
  };
  
  const handleCompleteRequest = (request: any) => {
    if (request.paymentMode === 'OFFLINE_AT_PARTNER' && request.paymentStatus === 'OFFLINE_PENDING') {
      setSelectedRequest(request);
      setShowOtpModal(true);
    } else {
      // Direct completion for online paid requests
      if (!user) return;
      updateRequest(request.id, { status: 'READY' }, user.id, 'PARTNER', 'Processing completed, ready for delivery');
    }
  };
  
  const handleVerifyOfflinePayment = () => {
    // Mock OTP verification
    if (otp === '123456' && selectedRequest && user) {
      updateRequest(
        selectedRequest.id, 
        { 
          status: 'READY', 
          paymentStatus: 'OFFLINE_VERIFIED' 
        }, 
        user.id, 
        'PARTNER', 
        'Offline payment verified via OTP'
      );
      setShowOtpModal(false);
      setOtp('');
      setSelectedRequest(null);
    }
  };
  
  if (!partner) {
    return (
      <div className="min-h-screen bg-bg py-12">
        <div className="max-w-lg mx-auto px-4 text-center">
          <Card className="p-8">
            <Users className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h2 className="text-xl font-bold text-navy mb-2">Not a Partner</h2>
            <p className="text-gray-600 mb-6">
              You are not registered as a partner yet. Register to start fulfilling service requests.
            </p>
            <Button onClick={() => navigate('/partner-register')}>
              Register as Partner
            </Button>
          </Card>
        </div>
      </div>
    );
  }
  
  return (
    <div className="min-h-screen bg-bg py-8 animate-fade-in">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
          <div>
            <h1 className="text-2xl font-bold text-navy">Partner Dashboard</h1>
            <p className="text-gray-600">Welcome back, {partner.ownerName}</p>
          </div>
          <VerificationBadge status={partner.verificationStatus} />
        </div>
        
        {/* Stats */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="bg-gradient-to-br from-saffron to-saffron-dark text-white">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-orange-100 text-sm">Pending Requests</p>
                <p className="text-3xl font-bold mt-1">{stats.pending}</p>
              </div>
              <Clock className="w-10 h-10 text-white/30" />
            </div>
          </Card>
          
          <Card className="bg-gradient-to-br from-green to-green-dark text-white">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-green-100 text-sm">Completed</p>
                <p className="text-3xl font-bold mt-1">{stats.completed}</p>
              </div>
              <CheckCircle className="w-10 h-10 text-white/30" />
            </div>
          </Card>
          
          <Card className="bg-gradient-to-br from-blue-500 to-blue-600 text-white">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-blue-100 text-sm">Wallet Balance</p>
                <p className="text-3xl font-bold mt-1">₹{stats.walletBalance}</p>
              </div>
              <Wallet className="w-10 h-10 text-white/30" />
            </div>
          </Card>
          
          <Card className="bg-gradient-to-br from-purple-500 to-purple-600 text-white">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-purple-100 text-sm">Total Earnings</p>
                <p className="text-3xl font-bold mt-1">₹{stats.totalEarnings}</p>
              </div>
              <TrendingUp className="w-10 h-10 text-white/30" />
            </div>
          </Card>
        </div>
        
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Pending Requests */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader 
                title="Assigned Requests" 
                subtitle="Requests assigned to you for processing"
              />
              
              {pendingRequests.length > 0 ? (
                <div className="space-y-4">
                  {pendingRequests.map(request => {
                    const service = services.find(s => s.id === request.serviceId);
                    return (
                      <div 
                        key={request.id}
                        className="p-4 bg-gray-50 rounded-xl"
                      >
                        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                          <div className="flex items-start gap-4">
                            <div className="w-10 h-10 bg-saffron/10 rounded-lg flex items-center justify-center shrink-0">
                              <FileText className="w-5 h-5 text-saffron" />
                            </div>
                            <div>
                              <p className="font-medium text-navy">{service?.name}</p>
                              <p className="text-sm text-gray-500 font-mono">ID: {request.id}</p>
                              <div className="flex items-center gap-3 mt-2">
                                <StatusBadge status={request.status} />
                                <span className="text-sm text-gray-500">
                                  {request.paymentMode === 'OFFLINE_AT_PARTNER' ? '💵 Pay at Shop' : '✅ Paid Online'}
                                </span>
                              </div>
                            </div>
                          </div>
                          
                          <div className="flex items-center gap-2">
                            {request.status === 'ASSIGNED' && (
                              <Button 
                                size="sm"
                                onClick={() => handleAcceptRequest(request.id)}
                              >
                                Accept
                              </Button>
                            )}
                            {request.status === 'PROCESSING' && (
                              <Button 
                                size="sm"
                                variant="secondary"
                                onClick={() => handleCompleteRequest(request)}
                              >
                                Mark Complete
                              </Button>
                            )}
                            <Button 
                              size="sm" 
                              variant="ghost"
                              onClick={() => navigate(`/request/${request.id}`)}
                            >
                              View <ArrowRight className="w-4 h-4 ml-1" />
                            </Button>
                          </div>
                        </div>
                        
                        {/* Customer Contact */}
                        <div className="mt-3 pt-3 border-t border-gray-200 flex items-center gap-4 text-sm text-gray-600">
                          <span>Customer: {request.formData.full_name || request.formData.applicant_name || 'N/A'}</span>
                          {request.formData.mobile && (
                            <a 
                              href={`tel:${request.formData.mobile}`}
                              className="flex items-center gap-1 text-saffron hover:underline"
                            >
                              <Phone className="w-4 h-4" />
                              {request.formData.mobile}
                            </a>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="text-center py-12">
                  <FileText className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                  <p className="text-gray-600">No pending requests</p>
                  <p className="text-sm text-gray-500">New requests will appear here when assigned</p>
                </div>
              )}
            </Card>
          </div>
          
          {/* Wallet & Recent Transactions */}
          <div className="space-y-6">
            {/* Wallet Card */}
            <Card className="bg-gradient-to-br from-navy to-navy-light text-white">
              <div className="flex items-center justify-between mb-4">
                <Wallet className="w-8 h-8" />
                <span className="text-xs bg-white/20 px-2 py-1 rounded-full">Partner Wallet</span>
              </div>
              <p className="text-gray-300 text-sm">Available Balance</p>
              <p className="text-4xl font-bold mt-1">₹{partner.walletBalance}</p>
              <div className="mt-4 pt-4 border-t border-white/20">
                <Button 
                  variant="outline" 
                  size="sm"
                  className="border-white text-white hover:bg-white hover:text-navy w-full"
                >
                  <Download className="w-4 h-4 mr-2" />
                  Request Withdrawal
                </Button>
              </div>
            </Card>
            
            {/* Recent Transactions */}
            <Card>
              <CardHeader title="Recent Transactions" />
              {walletTransactions.length > 0 ? (
                <div className="space-y-3">
                  {walletTransactions.slice(0, 5).map(txn => (
                    <div key={txn.id} className="flex items-center justify-between py-2 border-b border-gray-100 last:border-0">
                      <div className="flex items-center gap-3">
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                          txn.type === 'CREDIT' ? 'bg-green/10' : 'bg-red-100'
                        }`}>
                          {txn.type === 'CREDIT' 
                            ? <Plus className="w-4 h-4 text-green" />
                            : <Minus className="w-4 h-4 text-red-500" />
                          }
                        </div>
                        <div>
                          <p className="text-sm font-medium text-navy">{txn.description}</p>
                          <p className="text-xs text-gray-500">
                            {new Date(txn.createdAt).toLocaleDateString()}
                          </p>
                        </div>
                      </div>
                      <span className={`font-semibold ${
                        txn.type === 'CREDIT' ? 'text-green' : 'text-red-500'
                      }`}>
                        {txn.type === 'CREDIT' ? '+' : '-'}₹{txn.amount}
                      </span>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-gray-500 text-center py-4">No transactions yet</p>
              )}
            </Card>
            
            {/* Shop Details */}
            <Card>
              <CardHeader title="Shop Details" />
              <div className="space-y-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600">Shop Name</span>
                  <span className="font-medium text-navy">{partner.shopName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Owner</span>
                  <span className="font-medium text-navy">{partner.ownerName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Block</span>
                  <span className="font-medium text-navy capitalize">{partner.block}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Mobile</span>
                  <span className="font-medium text-navy">{partner.mobile}</span>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </div>
      
      {/* OTP Verification Modal */}
      <Modal
        isOpen={showOtpModal}
        onClose={() => setShowOtpModal(false)}
        title="Verify Offline Payment"
        size="sm"
      >
        <div className="text-center">
          <p className="text-gray-600 mb-4">
            An OTP has been sent to the customer's mobile number. 
            Please enter the OTP to confirm payment collection.
          </p>
          <Input
            placeholder="Enter 6-digit OTP"
            value={otp}
            onChange={(e) => setOtp(e.target.value.replace(/\D/g, '').slice(0, 6))}
            className="text-center text-2xl tracking-widest font-mono mb-4"
          />
          <p className="text-xs text-gray-500 mb-4">Demo OTP: 123456</p>
          <Button 
            className="w-full"
            onClick={handleVerifyOfflinePayment}
            disabled={otp.length !== 6}
          >
            Verify & Confirm Payment
          </Button>
        </div>
      </Modal>
    </div>
  );
};
