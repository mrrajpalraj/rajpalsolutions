import React from 'react';
import { RefreshCcw } from 'lucide-react';
import { Card } from '@/components/ui/Card';

export const RefundPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-bg py-12 animate-fade-in">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-saffron/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <RefreshCcw className="w-8 h-8 text-saffron" />
          </div>
          <h1 className="text-3xl font-bold text-navy mb-2">Refund Policy</h1>
          <p className="text-gray-600">Last updated: January 2025</p>
        </div>
        
        <Card className="prose prose-slate max-w-none">
          <div className="space-y-6 text-gray-700">
            <section>
              <h2 className="text-xl font-semibold text-navy mb-3">1. Overview</h2>
              <p>
                At Rajpal Solutions, we strive to provide excellent service. This Refund Policy 
                outlines the circumstances under which refunds may be granted and the process 
                for requesting them.
              </p>
            </section>
            
            <section>
              <h2 className="text-xl font-semibold text-navy mb-3">2. Refund Eligibility</h2>
              <p className="mb-3">Refunds may be granted in the following cases:</p>
              
              <div className="bg-green/10 p-4 rounded-lg mb-4">
                <h3 className="font-semibold text-green mb-2">✓ Full Refund Eligible</h3>
                <ul className="list-disc pl-6 space-y-1">
                  <li>Duplicate payment made in error</li>
                  <li>Service request cancelled before processing begins</li>
                  <li>Technical error causing incorrect charges</li>
                  <li>Service not available in your area (discovered after payment)</li>
                </ul>
              </div>
              
              <div className="bg-yellow-50 p-4 rounded-lg mb-4">
                <h3 className="font-semibold text-yellow-700 mb-2">⚠ Partial Refund Eligible</h3>
                <ul className="list-disc pl-6 space-y-1">
                  <li>Request cancelled after processing has started (processing fees deducted)</li>
                  <li>Service partially completed before cancellation</li>
                  <li>Government fee already paid to authorities (only service fee refundable)</li>
                </ul>
              </div>
              
              <div className="bg-red-50 p-4 rounded-lg">
                <h3 className="font-semibold text-red-600 mb-2">✗ Not Eligible for Refund</h3>
                <ul className="list-disc pl-6 space-y-1">
                  <li>Application rejected by government due to ineligibility</li>
                  <li>Rejection due to incorrect/fraudulent information provided by user</li>
                  <li>Documents submitted and processed by government</li>
                  <li>Request completed and documents delivered</li>
                  <li>Government fees already deposited with authorities</li>
                </ul>
              </div>
            </section>
            
            <section>
              <h2 className="text-xl font-semibold text-navy mb-3">3. Refund Timeline</h2>
              <table className="w-full border-collapse border border-gray-200 mt-2">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="border border-gray-200 px-4 py-2 text-left">Payment Method</th>
                    <th className="border border-gray-200 px-4 py-2 text-left">Refund Timeline</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td className="border border-gray-200 px-4 py-2">UPI / Net Banking</td>
                    <td className="border border-gray-200 px-4 py-2">3-5 business days</td>
                  </tr>
                  <tr>
                    <td className="border border-gray-200 px-4 py-2">Credit Card</td>
                    <td className="border border-gray-200 px-4 py-2">5-7 business days</td>
                  </tr>
                  <tr>
                    <td className="border border-gray-200 px-4 py-2">Debit Card</td>
                    <td className="border border-gray-200 px-4 py-2">5-7 business days</td>
                  </tr>
                  <tr>
                    <td className="border border-gray-200 px-4 py-2">Wallet</td>
                    <td className="border border-gray-200 px-4 py-2">1-2 business days</td>
                  </tr>
                  <tr>
                    <td className="border border-gray-200 px-4 py-2">Cash (at Partner)</td>
                    <td className="border border-gray-200 px-4 py-2">Same day at partner location</td>
                  </tr>
                </tbody>
              </table>
            </section>
            
            <section>
              <h2 className="text-xl font-semibold text-navy mb-3">4. How to Request a Refund</h2>
              <ol className="list-decimal pl-6 space-y-2">
                <li>
                  <strong>Contact Us:</strong> Call us at 8269342506 or 8085227600, or send an 
                  email to refund@rajpalsolutions.in
                </li>
                <li>
                  <strong>Provide Details:</strong> Include your Request ID, payment transaction ID, 
                  and reason for refund
                </li>
                <li>
                  <strong>Verification:</strong> Our team will verify your request within 1-2 business days
                </li>
                <li>
                  <strong>Processing:</strong> If approved, refund will be initiated to the original 
                  payment method
                </li>
                <li>
                  <strong>Confirmation:</strong> You will receive an SMS/email confirmation once 
                  refund is processed
                </li>
              </ol>
            </section>
            
            <section>
              <h2 className="text-xl font-semibold text-navy mb-3">5. Cancellation Policy</h2>
              <p className="mb-2">You can cancel your service request at any stage with the following conditions:</p>
              <ul className="list-disc pl-6 space-y-1">
                <li><strong>Before Processing:</strong> Full refund (minus payment gateway charges if any)</li>
                <li><strong>During Processing:</strong> Partial refund based on work completed</li>
                <li><strong>After Submission to Govt:</strong> No refund (government fees non-refundable)</li>
                <li><strong>After Completion:</strong> No refund</li>
              </ul>
            </section>
            
            <section>
              <h2 className="text-xl font-semibold text-navy mb-3">6. Delivery Fee Refunds</h2>
              <p>
                Delivery fees are refundable only if:
              </p>
              <ul className="list-disc pl-6 space-y-1 mt-2">
                <li>The service request is cancelled before dispatch</li>
                <li>We are unable to deliver to your address</li>
                <li>Documents are lost in transit (full refund + reprocessing)</li>
              </ul>
            </section>
            
            <section>
              <h2 className="text-xl font-semibold text-navy mb-3">7. Partner Payment Refunds</h2>
              <p>
                For payments made at partner centers (offline payment):
              </p>
              <ul className="list-disc pl-6 space-y-1 mt-2">
                <li>Refunds will be processed at the same partner center</li>
                <li>You must present your receipt and ID proof</li>
                <li>Partner will verify with our system via OTP</li>
              </ul>
            </section>
            
            <section>
              <h2 className="text-xl font-semibold text-navy mb-3">8. Disputes</h2>
              <p>
                If you disagree with a refund decision, you may escalate by:
              </p>
              <ol className="list-decimal pl-6 space-y-1 mt-2">
                <li>Writing to grievance@rajpalsolutions.in with full details</li>
                <li>Our Grievance Officer will respond within 7 days</li>
                <li>Further escalation options as per Terms of Service</li>
              </ol>
            </section>
            
            <section>
              <h2 className="text-xl font-semibold text-navy mb-3">9. Contact for Refunds</h2>
              <div className="bg-gray-50 p-4 rounded-lg mt-2">
                <p><strong>Refund Support</strong></p>
                <p>Phone: 8269342506, 8085227600</p>
                <p>Email: refund@rajpalsolutions.in</p>
                <p>Hours: Monday - Saturday, 9:00 AM - 7:00 PM</p>
                <p className="mt-2 text-sm text-gray-500">
                  Please have your Request ID and payment details ready when contacting us.
                </p>
              </div>
            </section>
            
            <section>
              <h2 className="text-xl font-semibold text-navy mb-3">10. Policy Updates</h2>
              <p>
                This policy may be updated from time to time. The current version will always 
                be available on this page. Significant changes will be communicated via email 
                or website notification.
              </p>
            </section>
          </div>
        </Card>
      </div>
    </div>
  );
};
