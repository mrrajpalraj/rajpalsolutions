import React from 'react';
import { cn } from '@/utils/cn';
import { RequestStatus, VerificationStatus, PaymentStatus } from '@/types';

interface BadgeProps {
  children: React.ReactNode;
  variant?: 'default' | 'success' | 'warning' | 'error' | 'info';
  size?: 'sm' | 'md';
  className?: string;
}

export const Badge: React.FC<BadgeProps> = ({
  children,
  variant = 'default',
  size = 'md',
  className
}) => {
  const variants = {
    default: 'bg-gray-100 text-gray-700',
    success: 'bg-green-100 text-green-700',
    warning: 'bg-yellow-100 text-yellow-700',
    error: 'bg-red-100 text-red-700',
    info: 'bg-blue-100 text-blue-700'
  };
  
  const sizes = {
    sm: 'px-2 py-0.5 text-xs',
    md: 'px-3 py-1 text-sm'
  };
  
  return (
    <span
      className={cn(
        'inline-flex items-center font-medium rounded-full',
        variants[variant],
        sizes[size],
        className
      )}
    >
      {children}
    </span>
  );
};

export const StatusBadge: React.FC<{ status: RequestStatus }> = ({ status }) => {
  const statusConfig: Record<RequestStatus, { label: string; variant: BadgeProps['variant'] }> = {
    DRAFT: { label: 'Draft', variant: 'default' },
    SUBMITTED: { label: 'Submitted', variant: 'info' },
    AWAITING_DOCUMENTS: { label: 'Awaiting Documents', variant: 'warning' },
    IN_REVIEW: { label: 'In Review', variant: 'info' },
    ASSIGNED: { label: 'Assigned', variant: 'info' },
    PROCESSING: { label: 'Processing', variant: 'warning' },
    READY: { label: 'Ready', variant: 'success' },
    COMPLETED: { label: 'Completed', variant: 'success' },
    CLOSED: { label: 'Closed', variant: 'default' },
    REFUNDED: { label: 'Refunded', variant: 'error' }
  };
  
  const config = statusConfig[status];
  return <Badge variant={config.variant}>{config.label}</Badge>;
};

export const VerificationBadge: React.FC<{ status: VerificationStatus }> = ({ status }) => {
  const config: Record<VerificationStatus, { label: string; variant: BadgeProps['variant'] }> = {
    PENDING: { label: 'Pending', variant: 'warning' },
    UNDER_REVIEW: { label: 'Under Review', variant: 'info' },
    APPROVED: { label: 'Approved', variant: 'success' },
    REJECTED: { label: 'Rejected', variant: 'error' }
  };
  
  return <Badge variant={config[status].variant}>{config[status].label}</Badge>;
};

export const PaymentBadge: React.FC<{ status: PaymentStatus }> = ({ status }) => {
  const config: Record<PaymentStatus, { label: string; variant: BadgeProps['variant'] }> = {
    PENDING: { label: 'Pending', variant: 'warning' },
    PAID: { label: 'Paid', variant: 'success' },
    FAILED: { label: 'Failed', variant: 'error' },
    REFUNDED: { label: 'Refunded', variant: 'default' },
    OFFLINE_PENDING: { label: 'Offline Pending', variant: 'warning' },
    OFFLINE_VERIFIED: { label: 'Offline Verified', variant: 'success' }
  };
  
  return <Badge variant={config[status].variant}>{config[status].label}</Badge>;
};
