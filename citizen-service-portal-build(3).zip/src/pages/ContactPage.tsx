import React, { useState } from 'react';
import { MapPin, Phone, Globe, Mail, Clock, Send, CheckCircle } from 'lucide-react';
import { Card, CardHeader } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Input, Textarea, Select } from '@/components/ui/Input';

export const ContactPage: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    mobile: '',
    email: '',
    subject: '',
    message: ''
  });
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    await new Promise(resolve => setTimeout(resolve, 1500));
    setSubmitted(true);
    setLoading(false);
  };
  
  if (submitted) {
    return (
      <div className="min-h-screen bg-bg py-16 animate-fade-in">
        <div className="max-w-lg mx-auto px-4 text-center">
          <Card className="p-8">
            <div className="w-20 h-20 bg-green/10 rounded-full flex items-center justify-center mx-auto mb-6">
              <CheckCircle className="w-10 h-10 text-green" />
            </div>
            <h2 className="text-2xl font-bold text-navy mb-2">Message Sent!</h2>
            <p className="text-gray-600 mb-6">
              Thank you for contacting us. We'll get back to you within 24 hours.
            </p>
            <Button onClick={() => setSubmitted(false)}>
              Send Another Message
            </Button>
          </Card>
        </div>
      </div>
    );
  }
  
  return (
    <div className="min-h-screen bg-bg py-12 animate-fade-in">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-3xl font-bold text-navy mb-4">Contact Us</h1>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Have questions about our services? We're here to help! Reach out to us through any of the channels below.
          </p>
        </div>
        
        <div className="grid lg:grid-cols-2 gap-8">
          {/* Contact Form */}
          <Card>
            <CardHeader 
              title="Send us a Message" 
              subtitle="Fill out the form and we'll get back to you"
            />
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid sm:grid-cols-2 gap-4">
                <Input
                  label="Your Name"
                  value={formData.name}
                  onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                  required
                />
                <Input
                  label="Mobile Number"
                  type="tel"
                  value={formData.mobile}
                  onChange={(e) => setFormData(prev => ({ ...prev, mobile: e.target.value }))}
                  required
                />
              </div>
              <Input
                label="Email"
                type="email"
                value={formData.email}
                onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
              />
              <Select
                label="Subject"
                value={formData.subject}
                onChange={(e) => setFormData(prev => ({ ...prev, subject: e.target.value }))}
                options={[
                  'General Inquiry',
                  'Service Question',
                  'Request Status',
                  'Payment Issue',
                  'Partner Inquiry',
                  'Complaint',
                  'Other'
                ]}
                required
              />
              <Textarea
                label="Message"
                value={formData.message}
                onChange={(e) => setFormData(prev => ({ ...prev, message: e.target.value }))}
                placeholder="How can we help you?"
                required
              />
              <Button 
                type="submit" 
                className="w-full" 
                size="lg"
                loading={loading}
                icon={<Send className="w-4 h-4" />}
              >
                Send Message
              </Button>
            </form>
          </Card>
          
          {/* Contact Information */}
          <div className="space-y-6">
            {/* Office Address */}
            <Card>
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-saffron/10 rounded-xl flex items-center justify-center shrink-0">
                  <MapPin className="w-6 h-6 text-saffron" />
                </div>
                <div>
                  <h3 className="font-semibold text-navy mb-2">Office Address</h3>
                  <p className="text-gray-600">
                    <strong>Rajpal Solutions</strong><br />
                    In front of District Collectorate,<br />
                    Maharana Pratap Chouraha,<br />
                    Jabalpur Naka, Damoh<br />
                    Madhya Pradesh - 470661
                  </p>
                </div>
              </div>
            </Card>
            
            {/* Phone Numbers */}
            <Card>
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-green/10 rounded-xl flex items-center justify-center shrink-0">
                  <Phone className="w-6 h-6 text-green" />
                </div>
                <div>
                  <h3 className="font-semibold text-navy mb-2">Phone Numbers</h3>
                  <div className="space-y-2">
                    <a 
                      href="tel:8269342506" 
                      className="flex items-center gap-2 text-gray-600 hover:text-saffron transition-colors"
                    >
                      <span className="font-mono text-lg">8269342506</span>
                      <span className="text-sm text-gray-400">(Primary)</span>
                    </a>
                    <a 
                      href="tel:8085227600" 
                      className="flex items-center gap-2 text-gray-600 hover:text-saffron transition-colors"
                    >
                      <span className="font-mono text-lg">8085227600</span>
                      <span className="text-sm text-gray-400">(Alternate)</span>
                    </a>
                  </div>
                </div>
              </div>
            </Card>
            
            {/* Website & Email */}
            <Card>
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center shrink-0">
                  <Globe className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-navy mb-2">Online</h3>
                  <div className="space-y-2">
                    <a 
                      href="https://rajpalsolutions.in" 
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-2 text-gray-600 hover:text-saffron transition-colors"
                    >
                      <Globe className="w-4 h-4" />
                      <span>Rajpalsolutions.in</span>
                    </a>
                    <a 
                      href="mailto:contact@rajpalsolutions.in"
                      className="flex items-center gap-2 text-gray-600 hover:text-saffron transition-colors"
                    >
                      <Mail className="w-4 h-4" />
                      <span>contact@rajpalsolutions.in</span>
                    </a>
                  </div>
                </div>
              </div>
            </Card>
            
            {/* Working Hours */}
            <Card>
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center shrink-0">
                  <Clock className="w-6 h-6 text-purple-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-navy mb-2">Working Hours</h3>
                  <div className="space-y-1 text-gray-600">
                    <p>Monday - Saturday: <span className="font-medium">9:00 AM - 7:00 PM</span></p>
                    <p>Sunday: <span className="font-medium text-red-500">Closed</span></p>
                  </div>
                </div>
              </div>
            </Card>
            
            {/* Map Placeholder */}
            <Card className="p-0 overflow-hidden">
              <div className="h-48 bg-gradient-to-br from-gray-100 to-gray-200 flex items-center justify-center">
                <div className="text-center">
                  <MapPin className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                  <p className="text-gray-500 text-sm">Map Location</p>
                  <p className="text-gray-400 text-xs">District Collectorate, Damoh</p>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};
