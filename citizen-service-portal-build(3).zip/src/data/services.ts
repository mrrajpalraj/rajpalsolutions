import { Service, ServiceCategory, FormSchema } from '@/types';

export const serviceCategories: ServiceCategory[] = [
  {
    id: 'pan',
    name: 'PAN Card Services',
    nameHi: 'पैन कार्ड सेवाएं',
    icon: 'CreditCard',
    description: 'New PAN, Correction, Reprint'
  },
  {
    id: 'aadhaar',
    name: 'Aadhaar Services',
    nameHi: 'आधार सेवाएं',
    icon: 'Fingerprint',
    description: 'Update assistance, correction'
  },
  {
    id: 'voter',
    name: 'Voter ID Services',
    nameHi: 'मतदाता पहचान पत्र',
    icon: 'Vote',
    description: 'New, Correction, Transfer'
  },
  {
    id: 'driving',
    name: 'Driving License',
    nameHi: 'ड्राइविंग लाइसेंस',
    icon: 'Car',
    description: 'New, Renewal, Duplicate'
  },
  {
    id: 'vehicle',
    name: 'Vehicle Services',
    nameHi: 'वाहन सेवाएं',
    icon: 'Truck',
    description: 'RC Transfer, Renewal'
  },
  {
    id: 'land',
    name: 'Land Records (MPLRC)',
    nameHi: 'भू-अभिलेख',
    icon: 'MapPin',
    description: 'Khasra, B1, Naksha, Certified Copy'
  },
  {
    id: 'certificates',
    name: 'Certificates',
    nameHi: 'प्रमाण पत्र',
    icon: 'FileCheck',
    description: 'Income, Residence, Caste'
  },
  {
    id: 'welfare',
    name: 'Welfare Schemes',
    nameHi: 'कल्याण योजनाएं',
    icon: 'Heart',
    description: 'Samagra, eShram, Ayushman'
  },
  {
    id: 'other',
    name: 'Other Services',
    nameHi: 'अन्य सेवाएं',
    icon: 'FileText',
    description: 'Typing, Printing, Scanning'
  }
];

export const formSchemas: Record<string, FormSchema> = {
  pan_new: {
    service: 'pan_new',
    steps: [
      {
        title: 'Basic Details',
        titleHi: 'मूल विवरण',
        fields: [
          { key: 'full_name', label: 'Full Name', labelHi: 'पूरा नाम', type: 'text', required: true, placeholder: 'As per documents' },
          { key: 'father_name', label: "Father's Name", labelHi: 'पिता का नाम', type: 'text', required: true },
          { key: 'dob', label: 'Date of Birth', labelHi: 'जन्म तिथि', type: 'date', required: true },
          { key: 'gender', label: 'Gender', labelHi: 'लिंग', type: 'select', options: ['Male', 'Female', 'Other'], required: true },
          { key: 'mobile', label: 'Mobile', labelHi: 'मोबाइल', type: 'tel', required: true, validation: { pattern: '^[6-9]\\d{9}$' } },
          { key: 'email', label: 'Email', labelHi: 'ईमेल', type: 'email', required: false }
        ]
      },
      {
        title: 'Address Details',
        titleHi: 'पता विवरण',
        fields: [
          { key: 'address_line1', label: 'Address Line 1', labelHi: 'पता पंक्ति 1', type: 'text', required: true },
          { key: 'address_line2', label: 'Address Line 2', labelHi: 'पता पंक्ति 2', type: 'text', required: false },
          { key: 'city', label: 'City/Village', labelHi: 'शहर/गांव', type: 'text', required: true },
          { key: 'district', label: 'District', labelHi: 'जिला', type: 'text', required: true },
          { key: 'state', label: 'State', labelHi: 'राज्य', type: 'select', options: ['Madhya Pradesh', 'Chhattisgarh', 'Maharashtra', 'Uttar Pradesh', 'Other'], required: true },
          { key: 'pincode', label: 'Pincode', labelHi: 'पिनकोड', type: 'text', required: true, validation: { pattern: '^[1-9][0-9]{5}$' } }
        ]
      },
      {
        title: 'Document Upload',
        titleHi: 'दस्तावेज़ अपलोड',
        uploads: [
          { tag: 'photo', label: 'Passport Photo', labelHi: 'पासपोर्ट फोटो', required: true, acceptedTypes: ['image/jpeg', 'image/png'], maxSizeMB: 2 },
          { tag: 'signature', label: 'Signature', labelHi: 'हस्ताक्षर', required: true, acceptedTypes: ['image/jpeg', 'image/png'], maxSizeMB: 1 },
          { tag: 'id_proof', label: 'ID Proof (Aadhaar/Voter ID)', labelHi: 'पहचान प्रमाण', required: true, acceptedTypes: ['image/jpeg', 'image/png', 'application/pdf'], maxSizeMB: 5 },
          { tag: 'address_proof', label: 'Address Proof', labelHi: 'पता प्रमाण', required: true, acceptedTypes: ['image/jpeg', 'image/png', 'application/pdf'], maxSizeMB: 5 }
        ]
      }
    ],
    consent: {
      text: 'I confirm that all details provided are correct and I authorize Rajpal Solutions to assist in processing my PAN card application.',
      textHi: 'मैं पुष्टि करता/करती हूं कि सभी विवरण सही हैं और मैं राजपाल सॉल्यूशंस को मेरे पैन कार्ड आवेदन में सहायता करने के लिए अधिकृत करता/करती हूं।'
    }
  },
  pan_correction: {
    service: 'pan_correction',
    steps: [
      {
        title: 'Existing PAN Details',
        titleHi: 'मौजूदा पैन विवरण',
        fields: [
          { key: 'existing_pan', label: 'Existing PAN Number', labelHi: 'मौजूदा पैन नंबर', type: 'text', required: true, validation: { pattern: '^[A-Z]{5}[0-9]{4}[A-Z]{1}$' } },
          { key: 'current_name', label: 'Name on PAN', labelHi: 'पैन पर नाम', type: 'text', required: true },
          { key: 'correction_type', label: 'What to Correct?', labelHi: 'क्या सुधारना है?', type: 'select', options: ['Name', 'Date of Birth', 'Father Name', 'Address', 'Photo/Signature', 'Multiple'], required: true }
        ]
      },
      {
        title: 'Corrected Details',
        titleHi: 'सही विवरण',
        fields: [
          { key: 'new_full_name', label: 'Correct Full Name', labelHi: 'सही पूरा नाम', type: 'text', required: false },
          { key: 'new_father_name', label: "Correct Father's Name", labelHi: 'सही पिता का नाम', type: 'text', required: false },
          { key: 'new_dob', label: 'Correct Date of Birth', labelHi: 'सही जन्म तिथि', type: 'date', required: false },
          { key: 'mobile', label: 'Mobile', labelHi: 'मोबाइल', type: 'tel', required: true }
        ]
      },
      {
        title: 'Document Upload',
        titleHi: 'दस्तावेज़ अपलोड',
        uploads: [
          { tag: 'existing_pan_copy', label: 'Existing PAN Copy', labelHi: 'मौजूदा पैन की कॉपी', required: true },
          { tag: 'photo', label: 'New Passport Photo', labelHi: 'नई पासपोर्ट फोटो', required: true },
          { tag: 'supporting_doc', label: 'Supporting Document for Correction', labelHi: 'सुधार के लिए सहायक दस्तावेज', required: true }
        ]
      }
    ],
    consent: {
      text: 'I confirm that the correction details provided are accurate and I authorize Rajpal Solutions to assist in processing.',
      textHi: 'मैं पुष्टि करता/करती हूं कि सुधार विवरण सही हैं और मैं राजपाल सॉल्यूशंस को प्रक्रिया में सहायता करने के लिए अधिकृत करता/करती हूं।'
    }
  },
  aadhaar_update: {
    service: 'aadhaar_update',
    steps: [
      {
        title: 'Basic Information',
        titleHi: 'मूल जानकारी',
        fields: [
          { key: 'aadhaar_last4', label: 'Aadhaar Last 4 Digits', labelHi: 'आधार के अंतिम 4 अंक', type: 'text', required: true, validation: { pattern: '^[0-9]{4}$' } },
          { key: 'full_name', label: 'Name on Aadhaar', labelHi: 'आधार पर नाम', type: 'text', required: true },
          { key: 'update_type', label: 'What to Update?', labelHi: 'क्या अपडेट करना है?', type: 'select', options: ['Name', 'Address', 'Date of Birth', 'Mobile Number', 'Email', 'Photo'], required: true },
          { key: 'mobile', label: 'Current Mobile', labelHi: 'वर्तमान मोबाइल', type: 'tel', required: true }
        ]
      },
      {
        title: 'Update Details',
        titleHi: 'अपडेट विवरण',
        fields: [
          { key: 'new_value', label: 'New Value', labelHi: 'नया मान', type: 'text', required: true },
          { key: 'reason', label: 'Reason for Update', labelHi: 'अपडेट का कारण', type: 'textarea', required: false }
        ]
      },
      {
        title: 'Document Upload',
        titleHi: 'दस्तावेज़ अपलोड',
        uploads: [
          { tag: 'supporting_doc', label: 'Supporting Document', labelHi: 'सहायक दस्तावेज', required: true },
          { tag: 'photo', label: 'Recent Photo (if updating photo)', labelHi: 'हाल की फोटो', required: false }
        ]
      }
    ],
    consent: {
      text: 'I confirm the update details are correct and authorize Rajpal Solutions to guide me through the update process.',
      textHi: 'मैं पुष्टि करता/करती हूं कि अपडेट विवरण सही हैं और राजपाल सॉल्यूशंस को अपडेट प्रक्रिया में मार्गदर्शन करने के लिए अधिकृत करता/करती हूं।'
    }
  },
  income_certificate: {
    service: 'income_certificate',
    steps: [
      {
        title: 'Applicant Details',
        titleHi: 'आवेदक विवरण',
        fields: [
          { key: 'full_name', label: 'Full Name', labelHi: 'पूरा नाम', type: 'text', required: true },
          { key: 'father_name', label: "Father's Name", labelHi: 'पिता का नाम', type: 'text', required: true },
          { key: 'dob', label: 'Date of Birth', labelHi: 'जन्म तिथि', type: 'date', required: true },
          { key: 'mobile', label: 'Mobile', labelHi: 'मोबाइल', type: 'tel', required: true },
          { key: 'occupation', label: 'Occupation', labelHi: 'व्यवसाय', type: 'select', options: ['Farmer', 'Labour', 'Business', 'Private Job', 'Govt Job', 'Unemployed', 'Student', 'Other'], required: true }
        ]
      },
      {
        title: 'Income & Address',
        titleHi: 'आय और पता',
        fields: [
          { key: 'annual_income', label: 'Annual Income (₹)', labelHi: 'वार्षिक आय (₹)', type: 'number', required: true },
          { key: 'income_source', label: 'Source of Income', labelHi: 'आय का स्रोत', type: 'text', required: true },
          { key: 'address', label: 'Full Address', labelHi: 'पूरा पता', type: 'textarea', required: true },
          { key: 'village_ward', label: 'Village/Ward', labelHi: 'ग्राम/वार्ड', type: 'text', required: true },
          { key: 'tehsil', label: 'Tehsil', labelHi: 'तहसील', type: 'text', required: true },
          { key: 'district', label: 'District', labelHi: 'जिला', type: 'text', required: true }
        ]
      },
      {
        title: 'Document Upload',
        titleHi: 'दस्तावेज़ अपलोड',
        uploads: [
          { tag: 'aadhaar', label: 'Aadhaar Card', labelHi: 'आधार कार्ड', required: true },
          { tag: 'ration_card', label: 'Ration Card', labelHi: 'राशन कार्ड', required: false },
          { tag: 'self_declaration', label: 'Self Declaration', labelHi: 'स्व-घोषणा', required: true }
        ]
      }
    ],
    consent: {
      text: 'I declare that the income details provided are true to the best of my knowledge and I authorize Rajpal Solutions to process my application.',
      textHi: 'मैं घोषणा करता/करती हूं कि आय विवरण मेरी जानकारी के अनुसार सत्य हैं और मैं राजपाल सॉल्यूशंस को मेरा आवेदन संसाधित करने के लिए अधिकृत करता/करती हूं।'
    }
  },
  khasra_nakal: {
    service: 'khasra_nakal',
    steps: [
      {
        title: 'Land Details',
        titleHi: 'भूमि विवरण',
        fields: [
          { key: 'owner_name', label: 'Land Owner Name', labelHi: 'भूमि स्वामी का नाम', type: 'text', required: true },
          { key: 'khasra_number', label: 'Khasra Number', labelHi: 'खसरा नंबर', type: 'text', required: true },
          { key: 'village', label: 'Village', labelHi: 'ग्राम', type: 'text', required: true },
          { key: 'patwari_halka', label: 'Patwari Halka', labelHi: 'पटवारी हल्का', type: 'text', required: true },
          { key: 'tehsil', label: 'Tehsil', labelHi: 'तहसील', type: 'text', required: true },
          { key: 'district', label: 'District', labelHi: 'जिला', type: 'select', options: ['Damoh', 'Sagar', 'Jabalpur', 'Other'], required: true }
        ]
      },
      {
        title: 'Applicant Details',
        titleHi: 'आवेदक विवरण',
        fields: [
          { key: 'applicant_name', label: 'Applicant Name', labelHi: 'आवेदक का नाम', type: 'text', required: true },
          { key: 'relation', label: 'Relation with Owner', labelHi: 'मालिक से संबंध', type: 'select', options: ['Self', 'Son', 'Daughter', 'Wife', 'Other'], required: true },
          { key: 'mobile', label: 'Mobile', labelHi: 'मोबाइल', type: 'tel', required: true },
          { key: 'purpose', label: 'Purpose', labelHi: 'उद्देश्य', type: 'select', options: ['Loan', 'Court Case', 'Mutation', 'Personal Record', 'Other'], required: true }
        ]
      },
      {
        title: 'Document Upload',
        titleHi: 'दस्तावेज़ अपलोड',
        uploads: [
          { tag: 'id_proof', label: 'ID Proof', labelHi: 'पहचान प्रमाण', required: true },
          { tag: 'previous_record', label: 'Previous Record (if any)', labelHi: 'पिछला रिकॉर्ड', required: false }
        ]
      }
    ],
    consent: {
      text: 'I authorize Rajpal Solutions to obtain the land record copy on my behalf.',
      textHi: 'मैं राजपाल सॉल्यूशंस को मेरी ओर से भू-अभिलेख प्रति प्राप्त करने के लिए अधिकृत करता/करती हूं।'
    }
  }
};

export const services: Service[] = [
  {
    id: 'pan_new',
    categoryId: 'pan',
    name: 'New PAN Card',
    nameHi: 'नया पैन कार्ड',
    description: 'Apply for a new PAN card with complete assistance',
    price: 199,
    deliveryFee: 50,
    processingTime: '7-10 working days',
    formSchema: formSchemas.pan_new,
    isActive: true
  },
  {
    id: 'pan_correction',
    categoryId: 'pan',
    name: 'PAN Correction',
    nameHi: 'पैन सुधार',
    description: 'Correct name, DOB, or other details on your PAN',
    price: 149,
    deliveryFee: 50,
    processingTime: '7-10 working days',
    formSchema: formSchemas.pan_correction,
    isActive: true
  },
  {
    id: 'pan_reprint',
    categoryId: 'pan',
    name: 'PAN Reprint',
    nameHi: 'पैन रीप्रिंट',
    description: 'Get a duplicate PAN card printed',
    price: 99,
    deliveryFee: 50,
    processingTime: '5-7 working days',
    formSchema: formSchemas.pan_new,
    isActive: true
  },
  {
    id: 'aadhaar_update',
    categoryId: 'aadhaar',
    name: 'Aadhaar Update Assistance',
    nameHi: 'आधार अपडेट सहायता',
    description: 'Get help with updating your Aadhaar details',
    price: 99,
    deliveryFee: 0,
    processingTime: '1-3 working days',
    formSchema: formSchemas.aadhaar_update,
    isActive: true
  },
  {
    id: 'voter_new',
    categoryId: 'voter',
    name: 'New Voter ID',
    nameHi: 'नया मतदाता पहचान पत्र',
    description: 'Register as a new voter and get your voter ID',
    price: 149,
    deliveryFee: 30,
    processingTime: '15-30 days',
    formSchema: formSchemas.pan_new,
    isActive: true
  },
  {
    id: 'dl_new',
    categoryId: 'driving',
    name: 'New Driving License',
    nameHi: 'नया ड्राइविंग लाइसेंस',
    description: 'Apply for a new driving license',
    price: 499,
    deliveryFee: 0,
    processingTime: '30-45 days',
    formSchema: formSchemas.pan_new,
    isActive: true
  },
  {
    id: 'dl_renewal',
    categoryId: 'driving',
    name: 'DL Renewal',
    nameHi: 'डीएल नवीनीकरण',
    description: 'Renew your expired driving license',
    price: 299,
    deliveryFee: 0,
    processingTime: '7-15 days',
    formSchema: formSchemas.pan_new,
    isActive: true
  },
  {
    id: 'rc_transfer',
    categoryId: 'vehicle',
    name: 'RC Transfer',
    nameHi: 'आरसी ट्रांसफर',
    description: 'Transfer vehicle registration to new owner',
    price: 799,
    deliveryFee: 0,
    processingTime: '15-30 days',
    formSchema: formSchemas.pan_new,
    isActive: true
  },
  {
    id: 'khasra_nakal',
    categoryId: 'land',
    name: 'Khasra Nakal (B1)',
    nameHi: 'खसरा नकल (B1)',
    description: 'Get certified copy of land record',
    price: 99,
    deliveryFee: 30,
    processingTime: '2-5 days',
    formSchema: formSchemas.khasra_nakal,
    isActive: true
  },
  {
    id: 'naksha',
    categoryId: 'land',
    name: 'Naksha (Map)',
    nameHi: 'नक्शा',
    description: 'Get land map/naksha from revenue records',
    price: 149,
    deliveryFee: 30,
    processingTime: '3-7 days',
    formSchema: formSchemas.khasra_nakal,
    isActive: true
  },
  {
    id: 'income_certificate',
    categoryId: 'certificates',
    name: 'Income Certificate',
    nameHi: 'आय प्रमाण पत्र',
    description: 'Get income certificate from tehsil',
    price: 149,
    deliveryFee: 30,
    processingTime: '7-15 days',
    formSchema: formSchemas.income_certificate,
    isActive: true
  },
  {
    id: 'residence_certificate',
    categoryId: 'certificates',
    name: 'Residence Certificate',
    nameHi: 'निवास प्रमाण पत्र',
    description: 'Get domicile/residence certificate',
    price: 149,
    deliveryFee: 30,
    processingTime: '7-15 days',
    formSchema: formSchemas.income_certificate,
    isActive: true
  },
  {
    id: 'caste_certificate',
    categoryId: 'certificates',
    name: 'Caste Certificate',
    nameHi: 'जाति प्रमाण पत्र',
    description: 'Get SC/ST/OBC caste certificate',
    price: 199,
    deliveryFee: 30,
    processingTime: '15-30 days',
    formSchema: formSchemas.income_certificate,
    isActive: true
  },
  {
    id: 'samagra',
    categoryId: 'welfare',
    name: 'Samagra ID',
    nameHi: 'समग्र आईडी',
    description: 'Registration and update assistance',
    price: 99,
    deliveryFee: 0,
    processingTime: '3-7 days',
    formSchema: formSchemas.aadhaar_update,
    isActive: true
  },
  {
    id: 'eshram',
    categoryId: 'welfare',
    name: 'e-Shram Card',
    nameHi: 'ई-श्रम कार्ड',
    description: 'Register for e-Shram card for workers',
    price: 49,
    deliveryFee: 0,
    processingTime: '1-2 days',
    formSchema: formSchemas.aadhaar_update,
    isActive: true
  },
  {
    id: 'ayushman',
    categoryId: 'welfare',
    name: 'Ayushman Card',
    nameHi: 'आयुष्मान कार्ड',
    description: 'Apply for Ayushman Bharat health card',
    price: 99,
    deliveryFee: 0,
    processingTime: '3-7 days',
    formSchema: formSchemas.aadhaar_update,
    isActive: true
  },
  {
    id: 'typing',
    categoryId: 'other',
    name: 'Typing Services',
    nameHi: 'टाइपिंग सेवाएं',
    description: 'Professional typing in Hindi/English',
    price: 20,
    deliveryFee: 0,
    processingTime: 'Same day',
    formSchema: formSchemas.aadhaar_update,
    isActive: true
  },
  {
    id: 'printing',
    categoryId: 'other',
    name: 'Printing & Scanning',
    nameHi: 'प्रिंटिंग और स्कैनिंग',
    description: 'B/W, Color printing and document scanning',
    price: 10,
    deliveryFee: 0,
    processingTime: 'Immediate',
    formSchema: formSchemas.aadhaar_update,
    isActive: true
  }
];

export const blocks = [
  { id: 'damoh', name: 'Damoh', district: 'Damoh' },
  { id: 'pathariya', name: 'Pathariya', district: 'Damoh' },
  { id: 'patera', name: 'Patera', district: 'Damoh' },
  { id: 'batiyagarh', name: 'Batiyagarh', district: 'Damoh' },
  { id: 'tendukheda', name: 'Tendukheda', district: 'Damoh' },
  { id: 'hatta', name: 'Hatta', district: 'Damoh' },
  { id: 'jabera', name: 'Jabera', district: 'Damoh' }
];
