import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Store, 
  User, 
  MapPin, 
  Phone, 
  FileCheck,
  ArrowRight,
  CheckCircle
} from 'lucide-react';
import { Card, CardHeader } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Input, Select, Textarea } from '@/components/ui/Input';
import { useAuthStore, usePartnerStore } from '@/store';
import { blocks, services } from '@/data/services';

export const PartnerRegisterPage: React.FC = () => {
  const navigate = useNavigate();
  const { user, isAuthenticated } = useAuthStore();
  const { createPartner, getPartnerByUserId } = usePartnerStore();
  
  const [formData, setFormData] = useState({
    shopName: '',
    ownerName: '',
    address: '',
    mobile: '',
    block: '',
    servicesOffered: [] as string[]
  });
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);
  
  const existingPartner = user ? getPartnerByUserId(user.id) : null;
  
  const handleServiceToggle = (serviceId: string) => {
    setFormData(prev => ({
      ...prev,
      servicesOffered: prev.servicesOffered.includes(serviceId)
        ? prev.servicesOffered.filter(s => s !== serviceId)
        : [...prev.servicesOffered, serviceId]
    }));
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!isAuthenticated || !user) {
      navigate('/login', { state: { from: '/partner-register' } });
      return;
    }
    
    setLoading(true);
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    createPartner({
      userId: user.id,
      shopName: formData.shopName,
      ownerName: formData.ownerName,
      address: formData.address,
      mobile: formData.mobile,
      block: formData.block,
      servicesOffered: formData.servicesOffered,
      verificationStatus: 'PENDING'
    });
    
    setLoading(false);
    setSubmitted(true);
  };
  
  if (existingPartner) {
    return (
      <div className="min-h-screen bg-bg py-12 animate-fade-in">
        <div className="max-w-lg mx-auto px-4">
          <Card className="text-center p-8">
            <div className="w-20 h-20 bg-green/10 rounded-full flex items-center justify-center mx-auto mb-6">
              <CheckCircle className="w-10 h-10 text-green" />
            </div>
            <h2 className="text-2xl font-bold text-navy mb-2">Already Registered!</h2>
            <p className="text-gray-600 mb-2">
              Your partner account is already registered.
            </p>
            <p className="text-sm text-gray-500 mb-6">
              Status: <span className="font-medium capitalize">{existingPartner.verificationStatus}</span>
            </p>
            <Button onClick={() => navigate('/partner')}>
              Go to Partner Dashboard
            </Button>
          </Card>
        </div>
      </div>
    );
  }
  
  if (submitted) {
    return (
      <div className="min-h-screen bg-bg py-12 animate-fade-in">
        <div className="max-w-lg mx-auto px-4">
          <Card className="text-center p-8">
            <div className="w-20 h-20 bg-green/10 rounded-full flex items-center justify-center mx-auto mb-6">
              <CheckCircle className="w-10 h-10 text-green" />
            </div>
            <h2 className="text-2xl font-bold text-navy mb-2">Application Submitted!</h2>
            <p className="text-gray-600 mb-6">
              Your partner registration has been submitted successfully. 
              Our team will verify your details and contact you within 2-3 business days.
            </p>
            <Button onClick={() => navigate('/partner')}>
              Go to Partner Dashboard
            </Button>
          </Card>
        </div>
      </div>
    );
  }
  
  return (
    <div className="min-h-screen bg-bg py-12 animate-fade-in">
      <div className="max-w-3xl mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-green/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <Store className="w-8 h-8 text-green" />
          </div>
          <h1 className="text-3xl font-bold text-navy mb-2">Become a Partner</h1>
          <p className="text-gray-600">
            Join our network and earn by helping citizens with government services
          </p>
        </div>
        
        {/* Benefits */}
        <div className="grid sm:grid-cols-3 gap-4 mb-8">
          {[
            { icon: FileCheck, title: 'Get Requests', desc: 'Receive service requests from your area' },
            { icon: User, title: 'Earn Commission', desc: 'Earn on every completed request' },
            { icon: MapPin, title: 'Local Coverage', desc: 'Serve customers in your block' }
          ].map((item, idx) => (
            <Card key={idx} className="text-center">
              <item.icon className="w-8 h-8 text-saffron mx-auto mb-2" />
              <h3 className="font-semibold text-navy">{item.title}</h3>
              <p className="text-sm text-gray-500">{item.desc}</p>
            </Card>
          ))}
        </div>
        
        {/* Registration Form */}
        <Card>
          <CardHeader 
            title="Partner Registration Form" 
            subtitle="Fill in your shop and contact details"
          />
          
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Shop Details */}
            <div className="space-y-4">
              <h3 className="font-medium text-navy flex items-center gap-2">
                <Store className="w-5 h-5 text-saffron" />
                Shop Details
              </h3>
              <div className="grid gap-4 sm:grid-cols-2">
                <Input
                  label="Shop/Center Name"
                  placeholder="e.g., Sharma Cyber Cafe"
                  value={formData.shopName}
                  onChange={(e) => setFormData(prev => ({ ...prev, shopName: e.target.value }))}
                  required
                />
                <Input
                  label="Owner Name"
                  placeholder="Your full name"
                  value={formData.ownerName}
                  onChange={(e) => setFormData(prev => ({ ...prev, ownerName: e.target.value }))}
                  required
                />
              </div>
              <Textarea
                label="Shop Address"
                placeholder="Complete address with landmark"
                value={formData.address}
                onChange={(e) => setFormData(prev => ({ ...prev, address: e.target.value }))}
                required
              />
            </div>
            
            {/* Contact & Location */}
            <div className="space-y-4">
              <h3 className="font-medium text-navy flex items-center gap-2">
                <MapPin className="w-5 h-5 text-saffron" />
                Contact & Location
              </h3>
              <div className="grid gap-4 sm:grid-cols-2">
                <Input
                  label="Mobile Number"
                  type="tel"
                  placeholder="10-digit mobile number"
                  value={formData.mobile}
                  onChange={(e) => setFormData(prev => ({ ...prev, mobile: e.target.value }))}
                  icon={<Phone className="w-5 h-5" />}
                  required
                />
                <Select
                  label="Block/Tehsil"
                  value={formData.block}
                  onChange={(e) => setFormData(prev => ({ ...prev, block: e.target.value }))}
                  options={blocks.map(b => ({ value: b.id, label: b.name }))}
                  required
                />
              </div>
            </div>
            
            {/* Services Offered */}
            <div className="space-y-4">
              <h3 className="font-medium text-navy flex items-center gap-2">
                <FileCheck className="w-5 h-5 text-saffron" />
                Services You Can Offer
              </h3>
              <p className="text-sm text-gray-500">Select the services you can help customers with</p>
              <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
                {services.slice(0, 12).map(service => (
                  <label 
                    key={service.id}
                    className={`flex items-center gap-2 p-3 border rounded-xl cursor-pointer transition-all ${
                      formData.servicesOffered.includes(service.id)
                        ? 'border-saffron bg-saffron/5'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <input
                      type="checkbox"
                      checked={formData.servicesOffered.includes(service.id)}
                      onChange={() => handleServiceToggle(service.id)}
                      className="accent-saffron"
                    />
                    <span className="text-sm text-navy">{service.name}</span>
                  </label>
                ))}
              </div>
            </div>
            
            {/* Terms */}
            <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-4">
              <label className="flex items-start gap-3 cursor-pointer">
                <input type="checkbox" required className="mt-1 accent-saffron" />
                <span className="text-sm text-gray-700">
                  I agree to the <a href="/terms" className="text-saffron hover:underline">Terms & Conditions</a> and 
                  confirm that all information provided is accurate. I understand that my application will be 
                  reviewed and I will be contacted for verification.
                </span>
              </label>
            </div>
            
            {/* Submit */}
            <div className="flex justify-end gap-4">
              <Button 
                type="button" 
                variant="ghost"
                onClick={() => navigate('/')}
              >
                Cancel
              </Button>
              <Button 
                type="submit"
                loading={loading}
                icon={<ArrowRight className="w-4 h-4" />}
              >
                {isAuthenticated ? 'Submit Application' : 'Login & Submit'}
              </Button>
            </div>
          </form>
        </Card>
      </div>
    </div>
  );
};
