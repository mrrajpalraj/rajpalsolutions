import React, { useState, useMemo } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { Search, Filter, Clock, ArrowRight, X } from 'lucide-react';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import { services, serviceCategories } from '@/data/services';

export const ServicesPage: React.FC = () => {
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const [searchQuery, setSearchQuery] = useState('');
  
  const selectedCategory = searchParams.get('category') || '';
  
  const filteredServices = useMemo(() => {
    return services.filter(service => {
      const matchesCategory = !selectedCategory || service.categoryId === selectedCategory;
      const matchesSearch = !searchQuery || 
        service.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        service.nameHi.includes(searchQuery) ||
        service.description.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesCategory && matchesSearch && service.isActive;
    });
  }, [selectedCategory, searchQuery]);
  
  const handleCategoryChange = (categoryId: string) => {
    if (categoryId === selectedCategory) {
      setSearchParams({});
    } else {
      setSearchParams({ category: categoryId });
    }
  };
  
  return (
    <div className="min-h-screen bg-bg py-8 animate-fade-in">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-navy mb-2">Our Services</h1>
          <p className="text-gray-600">
            Choose from our comprehensive list of government services
          </p>
        </div>
        
        {/* Filters */}
        <div className="mb-8 space-y-4">
          {/* Search */}
          <div className="max-w-md">
            <Input
              placeholder="Search services..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              icon={<Search className="w-5 h-5" />}
            />
          </div>
          
          {/* Category Pills */}
          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => setSearchParams({})}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                !selectedCategory 
                  ? 'bg-saffron text-white' 
                  : 'bg-white text-gray-600 hover:bg-gray-50 border border-gray-200'
              }`}
            >
              All Services
            </button>
            {serviceCategories.map((category) => (
              <button
                key={category.id}
                onClick={() => handleCategoryChange(category.id)}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-all flex items-center gap-2 ${
                  selectedCategory === category.id
                    ? 'bg-saffron text-white'
                    : 'bg-white text-gray-600 hover:bg-gray-50 border border-gray-200'
                }`}
              >
                {category.name}
                {selectedCategory === category.id && (
                  <X className="w-4 h-4" />
                )}
              </button>
            ))}
          </div>
        </div>
        
        {/* Results Count */}
        <div className="mb-6 flex items-center justify-between">
          <p className="text-gray-600">
            Showing <span className="font-semibold text-navy">{filteredServices.length}</span> services
          </p>
          <div className="flex items-center gap-2 text-sm text-gray-500">
            <Filter className="w-4 h-4" />
            <span>Filter by category</span>
          </div>
        </div>
        
        {/* Services Grid */}
        {filteredServices.length > 0 ? (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredServices.map((service) => {
              const category = serviceCategories.find(c => c.id === service.categoryId);
              return (
                <Card key={service.id} hover className="group flex flex-col h-full">
                  <div className="mb-4">
                    <span className="inline-block px-3 py-1 bg-saffron/10 text-saffron text-xs font-medium rounded-full">
                      {category?.name}
                    </span>
                  </div>
                  
                  <h3 className="text-lg font-semibold text-navy mb-1 group-hover:text-saffron transition-colors">
                    {service.name}
                  </h3>
                  <p className="text-gray-500 text-sm hindi-text mb-2">{service.nameHi}</p>
                  <p className="text-gray-600 text-sm mb-4 flex-1">{service.description}</p>
                  
                  <div className="flex items-center gap-2 text-sm text-gray-500 mb-4">
                    <Clock className="w-4 h-4" />
                    <span>{service.processingTime}</span>
                  </div>
                  
                  <div className="flex items-center justify-between pt-4 border-t border-gray-100">
                    <div>
                      <span className="text-2xl font-bold text-navy">₹{service.price}</span>
                      {service.deliveryFee > 0 && (
                        <span className="text-gray-400 text-sm ml-1">
                          +₹{service.deliveryFee}
                        </span>
                      )}
                    </div>
                    <Button 
                      size="sm"
                      onClick={() => navigate(`/apply/${service.id}`)}
                      icon={<ArrowRight className="w-4 h-4" />}
                    >
                      Apply
                    </Button>
                  </div>
                </Card>
              );
            })}
          </div>
        ) : (
          <div className="text-center py-16">
            <div className="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Search className="w-10 h-10 text-gray-400" />
            </div>
            <h3 className="text-xl font-semibold text-navy mb-2">No services found</h3>
            <p className="text-gray-500 mb-4">
              Try adjusting your search or filter criteria
            </p>
            <Button 
              variant="outline"
              onClick={() => {
                setSearchQuery('');
                setSearchParams({});
              }}
            >
              Clear Filters
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};
