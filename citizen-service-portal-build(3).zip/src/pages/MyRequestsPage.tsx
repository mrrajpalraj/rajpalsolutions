import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { FileText, Search, Filter, ArrowRight, Calendar, IndianRupee } from 'lucide-react';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import { StatusBadge, PaymentBadge } from '@/components/ui/Badge';
import { useAuthStore, useRequestStore } from '@/store';
import { services } from '@/data/services';
import { RequestStatus } from '@/types';

export const MyRequestsPage: React.FC = () => {
  const navigate = useNavigate();
  const { user } = useAuthStore();
  const { getRequestsByUser } = useRequestStore();
  
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<RequestStatus | ''>('');
  
  const userRequests = user ? getRequestsByUser(user.id) : [];
  
  const filteredRequests = userRequests.filter(request => {
    const service = services.find(s => s.id === request.serviceId);
    const matchesSearch = !searchQuery || 
      request.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      service?.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = !statusFilter || request.status === statusFilter;
    return matchesSearch && matchesStatus;
  });
  
  const statusOptions: RequestStatus[] = [
    'DRAFT', 'SUBMITTED', 'AWAITING_DOCUMENTS', 'IN_REVIEW', 
    'ASSIGNED', 'PROCESSING', 'READY', 'COMPLETED', 'CLOSED', 'REFUNDED'
  ];
  
  return (
    <div className="min-h-screen bg-bg py-8 animate-fade-in">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
          <div>
            <h1 className="text-2xl font-bold text-navy">My Requests</h1>
            <p className="text-gray-600">View and manage all your service applications</p>
          </div>
          <Button onClick={() => navigate('/services')}>
            New Request
          </Button>
        </div>
        
        {/* Filters */}
        <Card className="mb-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <Input
                placeholder="Search by ID or service name..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                icon={<Search className="w-5 h-5" />}
              />
            </div>
            <div className="flex items-center gap-2">
              <Filter className="w-5 h-5 text-gray-400" />
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value as RequestStatus | '')}
                className="px-4 py-2.5 bg-white border border-gray-200 rounded-xl text-navy focus:outline-none focus:border-saffron"
              >
                <option value="">All Status</option>
                {statusOptions.map(status => (
                  <option key={status} value={status}>
                    {status.replace(/_/g, ' ')}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </Card>
        
        {/* Results Count */}
        <p className="text-gray-600 mb-4">
          Showing <span className="font-semibold text-navy">{filteredRequests.length}</span> requests
        </p>
        
        {/* Requests List */}
        {filteredRequests.length > 0 ? (
          <div className="space-y-4">
            {filteredRequests.map(request => {
              const service = services.find(s => s.id === request.serviceId);
              return (
                <Card 
                  key={request.id} 
                  hover 
                  className="cursor-pointer"
                  onClick={() => navigate(`/request/${request.id}`)}
                >
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div className="flex items-start gap-4">
                      <div className="w-12 h-12 bg-saffron/10 rounded-xl flex items-center justify-center shrink-0">
                        <FileText className="w-6 h-6 text-saffron" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-navy">{service?.name || 'Unknown Service'}</h3>
                        <p className="text-sm text-gray-500 font-mono">ID: {request.id}</p>
                        <div className="flex items-center gap-4 mt-2 text-sm text-gray-500">
                          <span className="flex items-center gap-1">
                            <Calendar className="w-4 h-4" />
                            {new Date(request.createdAt).toLocaleDateString()}
                          </span>
                          <span className="flex items-center gap-1">
                            <IndianRupee className="w-4 h-4" />
                            {request.totalAmount}
                          </span>
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-4">
                      <div className="flex flex-col items-end gap-2">
                        <StatusBadge status={request.status} />
                        <PaymentBadge status={request.paymentStatus} />
                      </div>
                      <ArrowRight className="w-5 h-5 text-gray-400" />
                    </div>
                  </div>
                </Card>
              );
            })}
          </div>
        ) : (
          <Card className="text-center py-16">
            <FileText className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-navy mb-2">No requests found</h3>
            <p className="text-gray-600 mb-6">
              {userRequests.length === 0 
                ? "You haven't made any service requests yet."
                : "No requests match your search criteria."}
            </p>
            <Button onClick={() => navigate('/services')}>
              Browse Services
            </Button>
          </Card>
        )}
      </div>
    </div>
  );
};
